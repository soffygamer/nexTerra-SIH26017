import os
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator

from src.model_service import (
    get_alerts,
    get_case_by_id,
    get_cases,
    get_model_info,
    get_stats,
    load_cases,
    MODEL_PATH,
    predict_case,
)

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT.parent / "frontend"

app = FastAPI(
    title="NexTerra AI API",
    description="Land acquisition delay prediction API — SIH26017",
    version="2.0",
)

# Optional CORS for a separately hosted frontend.
allowed_origins = [
    origin.strip()
    for origin in os.getenv(
        "CORS_ORIGINS", ""
    ).split(",")
    if origin.strip()
]

if allowed_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
    )


@app.on_event("startup")
def startup_event():
    if MODEL_PATH.is_file():
        load_cases()


STAGE_REFERENCE_DAYS = {
    "Preliminary Notification": 45,
    "Social Impact Assessment": 60,
    "Declaration & Survey": 55,
    "Expert Group Review": 40,
    "Award (Compensation Determination)": 65,
    "Compensation Disbursement": 55,
    "Possession": 45,
}


class LandAcquisitionCase(BaseModel):
    """The exact 20-feature input contract used by the current model pipeline."""

    state: str = Field(min_length=2, max_length=80)
    district: str = Field(min_length=2, max_length=100)
    land_type: str = Field(min_length=2, max_length=40)
    project_type: str = Field(min_length=2, max_length=60)
    acquisition_stage: str = Field(min_length=2, max_length=80)
    stage_median_days_reference: int = Field(ge=1, le=1000)
    case_age_days: int = Field(ge=0, le=10000)
    days_in_stage: int = Field(ge=0, le=5000)
    number_of_landowners: int = Field(ge=1, le=1000000)
    land_area_hectares: float = Field(gt=0, le=100000000)
    litigation_present: int = Field(ge=0, le=1)
    litigation_type: str = Field(min_length=2, max_length=80)
    objection_present: int = Field(ge=0, le=1)
    objection_category: str = Field(min_length=2, max_length=100)
    number_of_objections: int = Field(ge=0, le=1000000)
    compensation_disputed: int = Field(ge=0, le=1)
    compensation_delay_days: int = Field(ge=0, le=10000)
    documentation_completeness_pct: float = Field(ge=0, le=100)
    previous_stage_delay_days: int = Field(ge=0, le=10000)
    historical_delay_rate: float = Field(ge=0, le=1)

    @model_validator(mode="after")
    def validate_case_categories(self):
        expected_stage_days = STAGE_REFERENCE_DAYS.get(self.acquisition_stage)
        if expected_stage_days is None:
            raise ValueError("acquisition_stage must match one of the seven model stages")
        if self.stage_median_days_reference != expected_stage_days:
            raise ValueError("stage_median_days_reference must match the selected stage")

        if (self.litigation_type == "No Litigation") != (self.litigation_present == 0):
            raise ValueError("litigation_present must agree with litigation_type")

        no_objections = self.objection_category == "No Objection"
        if no_objections and (self.objection_present != 0 or self.number_of_objections != 0):
            raise ValueError("Use No Objection with zero objections, or choose a category and enter a count")
        if not no_objections and (self.objection_present != 1 or self.number_of_objections < 1):
            raise ValueError("A selected objection category requires at least one objection")

        return self
@app.get("/")
def root():
    if (FRONTEND / "index.html").is_file():
        return FileResponse(FRONTEND / "index.html")

    return {
        "message": "NexTerra AI API is running",
        "docs": "/docs",
    }


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "service": "NexTerra AI API",
        "model_available": MODEL_PATH.is_file(),
    }


@app.get("/api/model-info")
def model_info():
    return get_model_info()


@app.post("/predict")
@app.post("/api/predict")
def predict(case: LandAcquisitionCase):
    try:
        return predict_case(case.model_dump())
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                "Prediction model is not installed. "
                "Run the training script first."
            ),
        ) from exc


@app.get("/cases")
def list_cases(
    state: Optional[str] = None,
    land_type: Optional[str] = None,
    acquisition_stage: Optional[str] = None,
    risk_level: Optional[str] = Query(
        None,
        description="LOW, MEDIUM, or HIGH",
    ),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
):
    try:
        return get_cases(
            state=state,
            land_type=land_type,
            acquisition_stage=acquisition_stage,
            risk_level=risk_level,
            limit=limit,
            offset=offset,
        )
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail="Prediction model is not installed.",
        ) from exc


@app.get("/cases/{case_id}")
def get_case(case_id: str):
    try:
        result = get_case_by_id(case_id)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail="Prediction model is not installed.",
        ) from exc

    if result is None:
        raise HTTPException(
            status_code=404,
            detail=f"Case '{case_id}' not found",
        )

    return result


@app.get("/alerts")
def alerts(
    limit: int = Query(50, ge=1, le=500)
):
    try:
        return {
            "alerts": get_alerts(limit=limit)
        }
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail="Prediction model is not installed.",
        ) from exc


@app.get("/stats")
def stats():
    try:
        return get_stats()
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail="Prediction model is not installed.",
        ) from exc


if FRONTEND.is_dir():
    app.mount(
        "/",
        StaticFiles(
            directory=FRONTEND,
            html=True,
        ),
        name="frontend",
    )
