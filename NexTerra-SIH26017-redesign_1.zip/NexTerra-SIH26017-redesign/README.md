# NexTerra — SIH 26017

NexTerra is a domain-aware, AI-powered predictive analytics and decision-support system for land acquisition monitoring under the **RFCTLARR Act, 2013** (*Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act, 2013*).

Designed for the Ministry and Special Land Acquisition Officers (SLAO), NexTerra replaces passive delay forecasting with proactive risk mitigation, calibrated statutory lapse warning, uncertainty quantification, and interactive GIS corridor intelligence.

---

## 🏛️ Domain-Compliant Architecture (SIH 26017)

```
┌────────────────────────────────────────────────────────────────────────┐
│                        DOMAIN-AWARE FEATURE PIPELINE                   │
│                                                                        │
│  Statutory Stages     Hierarchical Geo       External Signals          │
│  (RFCTLARR Sec 11-38) (TargetEncoding for    (Compensation disputes,   │
│  + Stage-valid logic   State/District Prior)  Documentation deficit)   │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                  MULTI-HEAD GRADIENT BOOSTING ENGINE                   │
│                  (HistGradientBoosting + Calibrated CV)                │
│                                                                        │
│    Head 1: Statutory Lapse Risk        Head 2: Quantile Regressor      │
│    P(Lapse under Sec 25 > 12 mo)       [P10, P50 (median), P90]        │
│    Calibrated Probabilities (AUC: 0.99) Uncertainty Range [Days]        │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                  DECISION SUPPORT & ACTION SIMULATOR                   │
│                                                                        │
│  • Bidirectional SHAP (Accelerators vs Protective Mitigators)          │
│  • "What-If" Counterfactual Simulator (/api/simulate) -> Days Saved    │
│  • Leaflet/GeoJSON Infrastructure Corridor Heatmap (/api/corridors)    │
└────────────────────────────────────────────────────────────────────────┘
```

---

## ⚖️ Procedural & Legal Alignment (RFCTLARR Act 2013)

1. **Strict Sequential Statutory Stages**:
   $$\text{Preliminary Notification (Sec 11)} \longrightarrow \text{SIA (Sec 4-7)} \longrightarrow \text{Declaration (Sec 19)} \longrightarrow \text{Award (Sec 23/25)} \longrightarrow \text{Disbursement} \longrightarrow \text{Possession (Sec 38)}$$
   - **Zero Prior Delays in Stage 1**: `previous_stage_delay_days == 0` for Preliminary Notification (Step 1).
   - **Zero Premature Compensation Disputes**: Compensation disputes and delays are strictly restricted to Stages 5–7 (Award and onwards), eliminating synthetic data leakage.
   - **Monotonically Increasing Case Lifecycles**: Case age increases realistically across stages (Stage 1 avg ~44 days to Stage 7 avg ~426 days).
2. **Real Administrative Districts & Official LGD Codes**:
   - 13 States and official Local Government Directory (LGD) mapped districts (Pune, Agra, Jaipur, Ahmedabad, Nagpur, Lucknow, etc.).
   - Exact geospatial coordinates (latitude, longitude) and linear project corridor IDs (`NH-48-EXP`, `DFC-WEST`, `MAHA-SAMRUDDHI`, `KEN-BETWA-CANAL`, etc.).
3. **RFCTLARR Section 25 Statutory Lapse Head**:
   - Under Section 25, if an Award is not published within 12 months (365 days) from Section 19 Declaration, the acquisition lapses completely.
   - Dedicated calibrated classifier predicts $P(\text{Statutory Lapse under Sec 25} > 365 \text{ days})$ (ROC-AUC: **0.9917**).

---

## 📈 Benchmark & Evaluation Performance

Evaluated on held-out geographic states (**Andhra Pradesh**, **Rajasthan**, **Uttar Pradesh**) via `GroupShuffleSplit`:

| Model / Baseline | MAE (Days) | RMSE (Days) | $R^2$ Score | Key Strengths / Status |
| :--- | :---: | :---: | :---: | :--- |
| **Median Baseline Predictor** | 32.63 d | 38.12 d | 0.0000 | Naive baseline |
| **Ridge Regression ($\alpha=10$)** | 6.52 d | 8.15 d | 0.9625 | Linear regularized baseline |
| **NexTerra HistGradientBoosting ($P_{50}$)** | **6.16 d** | **7.90 d** | **0.9647** | **~81% error reduction over median baseline** |
| **Uncertainty Quantification ($P_{10} - P_{90}$)** | — | — | — | **Captures 80% confidence interval** (Mean width: 15.1 d) |
| **Section 25 Statutory Lapse Classifier** | — | — | **0.9917 AUC** | **Calibrated Brier score: 0.0195** |

- **Target Encoding**: Replaced fragile one-hot encoding with `TargetEncoder(smooth="auto")`. When an unseen district or held-out state is evaluated, the model smoothly shrinks to the state/national prior instead of collapsing to zero vectors.
- **Lightweight Pre-Trained Artifact**: `backend/models/nexterra_delay_model.pkl` is pre-trained and committed (2.81 MB), completely eliminating HTTP 503 errors on fresh clones.

---

## 🔍 Explainability & Decision Support

1. **Bidirectional SHAP Attribution**:
   - **Delay Accelerators (+ days)**: Features driving delay upward (e.g., active litigation under Section 15, compensation valuation disputes, stage backlogs).
   - **Protective Mitigators (- days)**: Features actively buffering/reducing delay (e.g., 100% documentation completeness, clean title, zero litigation, swift survey progress).
2. **Interactive "What-If" Counterfactual Simulation Engine**:
   - Endpoint: `POST /api/simulate`
   - Test administrative interventions:
     - Fast-track joint survey (reduce days in stage from 60 to 15)
     - Settle litigation via Lok Adalat / Special Tribunal
     - Resolve compensation valuation disputes
     - Dispose formal objections
     - Bring documentation completeness to 100%
   - Returns: **Original delay $\rightarrow$ Simulated delay $\rightarrow$ Net Time Saved (Days & %)** and **Section 25 Lapse Risk Reduction %**.
3. **Geospatial Linear Corridor Intelligence (SIH 26017)**:
   - Endpoint: `GET /api/corridors` and `GET /api/gis/parcels`
   - Interactive Leaflet.js map with color-coded risk markers and corridor roll-up metrics across India.

---

## 🚀 Quickstart & Execution

### 1. Requirements

```bash
cd backend
pip install -r requirements.txt
```

### 2. Run Test Suite

```bash
python -m unittest tests/test_system.py
```
*(All 7 tests verify RFCTLARR invariants, quantiles, lapse risk, SHAP, and simulator).*

### 3. Start the Application

```bash
python -m uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload
```

- **Interactive Dashboard & GIS Map**: `http://localhost:8000`
- **Swagger API Docs**: `http://localhost:8000/docs`

---

## 📂 Project Structure

```text
NexTerra-SIH26017-redesign/
├── frontend/
│   └── index.html                # Interactive UI, Leaflet GIS map, What-If simulator, SHAP cards
├── backend/
│   ├── api/
│   │   └── main.py               # FastAPI endpoints (/predict, /simulate, /corridors, /gis/parcels)
│   ├── data/
│   │   └── nexterra_land_acquisition_8000_redesigned_v2.csv
│   ├── models/
│   │   ├── nexterra_delay_model.pkl   # Pre-trained lightweight ensemble pipeline (2.81 MB)
│   │   └── model_validation.json      # Validation benchmarks on held-out states
│   ├── src/
│   │   ├── generate_data.py      # RFCTLARR Act 2013 synthetic generator
│   │   ├── ensemble_pipeline.py  # NexTerraEnsemblePipeline (Quantiles + Lapse Head)
│   │   ├── train_model.py        # Multi-head training & state holdout evaluation
│   │   ├── model_service.py      # Inference, bidirectional SHAP, simulation engine
│   │   └── check_feature_importance.py
│   ├── tests/
│   │   └── test_system.py        # Comprehensive test suite
│   ├── requirements.txt
│   └── .gitignore
└── README.md
```
