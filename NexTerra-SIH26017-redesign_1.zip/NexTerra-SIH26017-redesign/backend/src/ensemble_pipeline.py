# pyright: basic
"""
NexTerra Ensemble Pipeline & Model Container
SIH 26017 - Domain-Aware Land Acquisition Predictive Engine

Provides:
- TargetEncoder preprocessor handling unseen states/districts gracefully
- Multi-Head Quantile Regressors (P10, P50, P90) for uncertainty quantification
- Point regressor for explained variance and metrics
- Calibrated Statutory Lapse Classifier predicting P(Lapse under Sec 25 > 12 mo)
- Complete backward compatibility with scikit-learn Pipeline interface (named_steps, predict)
"""

from typing import Any, Dict, List, Optional
import numpy as np
import pandas as pd


class NexTerraEnsemblePipeline:
    """Unified container for multi-head land acquisition delay and statutory risk prediction."""

    def __init__(
        self,
        preprocessor: Any,
        p10_model: Any,
        p50_model: Any,
        p90_model: Any,
        point_model: Any,
        lapse_classifier: Any,
        feature_columns: List[str],
        categorical_features: List[str],
        numeric_features: List[str],
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.preprocessor = preprocessor
        self.p10_model = p10_model
        self.p50_model = p50_model
        self.p90_model = p90_model
        self.point_model = point_model
        self.lapse_classifier = lapse_classifier
        self.feature_columns = feature_columns
        self.categorical_features = categorical_features
        self.numeric_features = numeric_features
        self.metadata = metadata or {}

        # Provide standard scikit-learn Pipeline-like named_steps for backward compatibility
        self.named_steps = {
            "preprocessor": preprocessor,
            "model": point_model,
            "p50_model": p50_model,
            "p10_model": p10_model,
            "p90_model": p90_model,
            "lapse_classifier": lapse_classifier,
        }

    def _prepare_df(self, X: Any) -> pd.DataFrame:
        if isinstance(X, pd.DataFrame):
            df = X.copy()
        elif isinstance(X, dict):
            df = pd.DataFrame([X])
        elif isinstance(X, list):
            df = pd.DataFrame(X)
        else:
            df = pd.DataFrame(X, columns=self.feature_columns)

        # Ensure all categorical features are valid strings (avoid np.nan dtype conflict in TargetEncoder)
        for col in self.categorical_features:
            if col not in df.columns:
                df[col] = "Unknown"
            else:
                df[col] = df[col].fillna("Unknown").astype(str)

        # Ensure all numeric features are valid numeric floats
        for col in self.numeric_features:
            if col not in df.columns:
                df[col] = 0.0
            else:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

        return df[self.feature_columns]

    def transform(self, X: Any) -> np.ndarray:
        df = self._prepare_df(X)
        transformed = self.preprocessor.transform(df)
        if hasattr(transformed, "toarray"):
            transformed = transformed.toarray()
        return np.asarray(transformed, dtype=np.float64)

    def predict(self, X: Any) -> np.ndarray:
        """Point prediction of additional delay in days (median / expected delay)."""
        X_trans = self.transform(X)
        preds = self.p50_model.predict(X_trans)
        return np.maximum(0.0, preds)

    def predict_quantiles(self, X: Any) -> Dict[str, np.ndarray]:
        """Return 80% confidence interval [P10 (best case), P50 (expected), P90 (worst case)]."""
        X_trans = self.transform(X)
        p10 = np.maximum(0.0, self.p10_model.predict(X_trans))
        p50 = np.maximum(p10, self.p50_model.predict(X_trans))
        p90 = np.maximum(p50, self.p90_model.predict(X_trans))
        return {
            "p10": np.round(p10, 1),
            "p50": np.round(p50, 1),
            "p90": np.round(p90, 1),
        }

    def predict_lapse_probability(self, X: Any) -> np.ndarray:
        """Calibrated probability of Statutory Lapse under Section 25 of RFCTLARR Act 2013."""
        X_trans = self.transform(X)
        if hasattr(self.lapse_classifier, "predict_proba"):
            probs = self.lapse_classifier.predict_proba(X_trans)
            return probs[:, 1]
        elif hasattr(self.lapse_classifier, "predict"):
            return self.lapse_classifier.predict(X_trans).astype(float)
        return np.zeros(len(X_trans))
