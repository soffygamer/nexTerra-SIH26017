# pyright: basic
"""
NexTerra Model Training Engine
SIH 26017 - Domain-Aware Multi-Head Gradient Boosting Engine

Architecture:
1. Feature Pipeline: TargetEncoder with smooth shrinkage for hierarchical geographic generalization.
2. Head 1 (Classification): Calibrated HistGradientBoostingClassifier for Section 25 Statutory Lapse Risk.
3. Head 2 (Quantile Regression): HistGradientBoostingRegressor for [P10, P50, P90] uncertainty intervals.
4. Comprehensive Validation on held-out geographic states with baselines comparison (Ridge, Dummy Median).
"""

import json
from pathlib import Path
import sys

# Ensure backend root is on path so ensemble_pipeline can be imported
BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import (
    HistGradientBoostingClassifier,
    HistGradientBoostingRegressor,
)
from sklearn.calibration import CalibratedClassifierCV
from sklearn.linear_model import Ridge
from sklearn.metrics import (
    brier_score_loss,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    roc_auc_score,
)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import TargetEncoder

from src.ensemble_pipeline import NexTerraEnsemblePipeline

ROOT = BACKEND_DIR
DATA_PATH = ROOT / "data" / "nexterra_land_acquisition_8000_redesigned_v2.csv"
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(parents=True, exist_ok=True)

TARGET_DELAY = "final_additional_delay_days"
TARGET_LAPSE = "statutory_lapse_risk"

CATEGORICAL_FEATURES = [
    "state",
    "district",
    "land_type",
    "project_type",
    "acquisition_stage",
    "litigation_type",
    "objection_category",
]

NUMERIC_FEATURES = [
    "stage_median_days_reference",
    "case_age_days",
    "days_in_stage",
    "number_of_landowners",
    "land_area_hectares",
    "litigation_present",
    "objection_present",
    "number_of_objections",
    "compensation_disputed",
    "compensation_delay_days",
    "documentation_completeness_pct",
    "previous_stage_delay_days",
    "historical_delay_rate",
]

FEATURE_COLUMNS = CATEGORICAL_FEATURES + NUMERIC_FEATURES


def train_models():
    print("=" * 65)
    print("NexTerra AI Model Training Engine (SIH 26017)")
    print("=" * 65)

    if not DATA_PATH.is_file():
        raise FileNotFoundError(f"Dataset not found at {DATA_PATH}")

    df = pd.read_csv(DATA_PATH)
    print(f"Loaded dataset: {DATA_PATH.name} ({len(df)} records)")

    X = df[FEATURE_COLUMNS]
    y_delay = df[TARGET_DELAY].astype(float)
    y_lapse = df[TARGET_LAPSE].astype(int)

    # Geographic generalization split: Hold out entire states
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=42)
    train_idx, test_idx = next(splitter.split(X, y_delay, groups=df["state"]))

    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_delay_train, y_delay_test = y_delay.iloc[train_idx], y_delay.iloc[test_idx]
    y_lapse_train, y_lapse_test = y_lapse.iloc[train_idx], y_lapse.iloc[test_idx]

    held_out_states = sorted(X_test["state"].unique())
    print(f"Training cases: {len(X_train)} across {X_train['state'].nunique()} states")
    print(f"Held-out test cases: {len(X_test)} across {len(held_out_states)} states: {held_out_states}")

    # 1. Feature Preprocessing with Target Encoding
    print("\nFitting TargetEncoder for geographic and categorical features...")
    preprocessor = ColumnTransformer(
        transformers=[
            (
                "cat",
                TargetEncoder(
                    smooth="auto",
                    target_type="continuous",
                    cv=5,
                    random_state=42,
                ),
                CATEGORICAL_FEATURES,
            ),
            ("num", "passthrough", NUMERIC_FEATURES),
        ]
    )

    X_train_trans = preprocessor.fit_transform(X_train, y_delay_train)
    X_test_trans = preprocessor.transform(X_test)

    # 2. Train Head 2: Multi-Quantile Regressor Engine
    print("\nTraining Head 2: Quantile Regressors (P10, P50, P90)...")
    p10_model = HistGradientBoostingRegressor(
        loss="quantile",
        quantile=0.10,
        max_iter=250,
        min_samples_leaf=20,
        random_state=42,
    )
    p50_model = HistGradientBoostingRegressor(
        loss="quantile",
        quantile=0.50,
        max_iter=250,
        min_samples_leaf=20,
        random_state=42,
    )
    p90_model = HistGradientBoostingRegressor(
        loss="quantile",
        quantile=0.90,
        max_iter=250,
        min_samples_leaf=20,
        random_state=42,
    )
    point_model = HistGradientBoostingRegressor(
        loss="squared_error",
        max_iter=250,
        min_samples_leaf=20,
        random_state=42,
    )

    p10_model.fit(X_train_trans, y_delay_train)
    p50_model.fit(X_train_trans, y_delay_train)
    p90_model.fit(X_train_trans, y_delay_train)
    point_model.fit(X_train_trans, y_delay_train)

    # 3. Train Head 1: Statutory Lapse Risk Classifier (Calibrated)
    print("\nTraining Head 1: Statutory Lapse Classifier (RFCTLARR Sec 25)...")
    lapse_base = HistGradientBoostingClassifier(
        max_iter=200,
        min_samples_leaf=20,
        random_state=42,
    )
    lapse_calibrated = CalibratedClassifierCV(
        estimator=lapse_base,
        method="sigmoid",
        cv=5,
    )
    lapse_calibrated.fit(X_train_trans, y_lapse_train)

    # 4. Benchmarks & Performance Evaluation on Held-Out States
    print("\nEvaluating models on held-out test states...")
    y_pred_point = point_model.predict(X_test_trans)
    y_pred_p10 = p10_model.predict(X_test_trans)
    y_pred_p50 = p50_model.predict(X_test_trans)
    y_pred_p90 = p90_model.predict(X_test_trans)

    # Baseline: Dummy Median
    dummy = DummyRegressor(strategy="median")
    dummy.fit(X_train_trans, y_delay_train)
    y_pred_dummy = dummy.predict(X_test_trans)

    # Baseline: Ridge Regression (alpha=10)
    ridge = Ridge(alpha=10.0)
    ridge.fit(X_train_trans, y_delay_train)
    y_pred_ridge = ridge.predict(X_test_trans)

    # Metrics
    mae_model = mean_absolute_error(y_delay_test, y_pred_point)
    rmse_model = mean_squared_error(y_delay_test, y_pred_point) ** 0.5
    r2_model = r2_score(y_delay_test, y_pred_point)

    mae_p50 = mean_absolute_error(y_delay_test, y_pred_p50)
    mae_dummy = mean_absolute_error(y_delay_test, y_pred_dummy)
    mae_ridge = mean_absolute_error(y_delay_test, y_pred_ridge)
    r2_ridge = r2_score(y_delay_test, y_pred_ridge)

    # Quantile Interval Coverage (P10 to P90 should capture ~80% of points)
    inside_interval = (y_delay_test >= y_pred_p10) & (y_delay_test <= y_pred_p90)
    coverage_80 = float(inside_interval.mean() * 100)
    mean_interval_width = float((y_pred_p90 - y_pred_p10).mean())

    # Classification Metrics
    y_prob_lapse = lapse_calibrated.predict_proba(X_test_trans)[:, 1]
    auc_lapse = roc_auc_score(y_lapse_test, y_prob_lapse)
    brier_lapse = brier_score_loss(y_lapse_test, y_prob_lapse)

    print("\n" + "=" * 50)
    print("REGRESSION PERFORMANCE ON HELD-OUT STATES:")
    print(f"  HistGradientBoosting Point MAE: {mae_model:.2f} days")
    print(f"  HistGradientBoosting Point RMSE: {rmse_model:.2f} days")
    print(f"  HistGradientBoosting Point R² : {r2_model:.4f}")
    print(f"  HistGradientBoosting P50 MAE  : {mae_p50:.2f} days")
    print(f"  Ridge Regression MAE          : {mae_ridge:.2f} days (R²: {r2_ridge:.4f})")
    print(f"  Median Baseline MAE           : {mae_dummy:.2f} days")
    print("\nUNCERTAINTY QUANTIFICATION (P10 - P90):")
    print(f"  Empirical 80% Coverage        : {coverage_80:.1f}%")
    print(f"  Average Interval Width        : {mean_interval_width:.1f} days")
    print("\nSTATUTORY LAPSE CLASSIFICATION (Sec 25):")
    print(f"  Calibrated ROC-AUC            : {auc_lapse:.4f}")
    print(f"  Brier Score (Calibration)     : {brier_lapse:.4f}")
    print("=" * 50)

    # 5. Package Ensemble Pipeline
    pipeline = NexTerraEnsemblePipeline(
        preprocessor=preprocessor,
        p10_model=p10_model,
        p50_model=p50_model,
        p90_model=p90_model,
        point_model=point_model,
        lapse_classifier=lapse_calibrated,
        feature_columns=FEATURE_COLUMNS,
        categorical_features=CATEGORICAL_FEATURES,
        numeric_features=NUMERIC_FEATURES,
        metadata={
            "held_out_states": held_out_states,
            "train_cases": len(X_train),
            "test_cases": len(X_test),
            "model_mae_days": round(float(mae_model), 2),
            "model_rmse_days": round(float(rmse_model), 2),
            "model_r2": round(float(r2_model), 4),
            "p50_mae_days": round(float(mae_p50), 2),
            "ridge_mae_days": round(float(mae_ridge), 2),
            "baseline_median_mae_days": round(float(mae_dummy), 2),
            "coverage_80_pct": round(coverage_80, 1),
            "interval_width_days": round(mean_interval_width, 1),
            "statutory_lapse_auc": round(float(auc_lapse), 4),
            "statutory_lapse_brier": round(float(brier_lapse), 4),
        },
    )

    # 6. Save Model Artifact and Report
    model_path = MODEL_DIR / "nexterra_delay_model.pkl"
    report_path = MODEL_DIR / "model_validation.json"

    joblib.dump(pipeline, model_path, compress=3)
    file_size_mb = model_path.stat().st_size / (1024 * 1024)

    validation_report = {
        "evaluation_split": "state_group_holdout",
        "held_out_states": held_out_states,
        "dataset_file": DATA_PATH.name,
        "total_rows": int(len(df)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "model_architecture": "Multi-Head HistGradientBoosting (Quantiles + Calibrated Lapse Classifier)",
        "model_mae_days": round(float(mae_model), 2),
        "model_rmse_days": round(float(rmse_model), 2),
        "model_r2": round(float(r2_model), 4),
        "p50_mae_days": round(float(mae_p50), 2),
        "ridge_mae_days": round(float(mae_ridge), 2),
        "median_baseline_mae_days": round(float(mae_dummy), 2),
        "coverage_80_pct": round(coverage_80, 1),
        "interval_width_days": round(mean_interval_width, 1),
        "statutory_lapse_auc": round(float(auc_lapse), 4),
        "statutory_lapse_brier": round(float(brier_lapse), 4),
        "model_artifact_size_mb": round(file_size_mb, 2),
    }

    report_path.write_text(json.dumps(validation_report, indent=2), encoding="utf-8")

    print(f"\nModel artifact saved successfully to: {model_path} ({file_size_mb:.2f} MB)")
    print(f"Validation report saved to: {report_path}")
    return pipeline, validation_report


if __name__ == "__main__":
    train_models()
