# pyright: basic
from pathlib import Path
import sys

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

import joblib
import pandas as pd
import numpy as np

MODEL_PATH = BACKEND_DIR / "models" / "nexterra_delay_model.pkl"
DATA_PATH = BACKEND_DIR / "data" / "nexterra_land_acquisition_8000_redesigned_v2.csv"

pipeline = joblib.load(MODEL_PATH)
df = pd.read_csv(DATA_PATH)

feature_cols = pipeline.feature_columns
X = df[feature_cols].head(500)
y = df["final_additional_delay_days"].head(500)

from sklearn.inspection import permutation_importance
X_trans = pipeline.transform(X)
result = permutation_importance(pipeline.p50_model, X_trans, y, n_repeats=5, random_state=42)

feature_names = pipeline.preprocessor.get_feature_names_out()

importance_df = pd.DataFrame({
    "feature": feature_names,
    "importance_mean": result.importances_mean,
    "importance_std": result.importances_std,
}).sort_values(by="importance_mean", ascending=False)

print("\n===== GLOBAL FEATURE IMPORTANCE (PERMUTATION) =====\n")
for _, row in importance_df.head(20).iterrows():
    print(f"{row['feature']:<45} {row['importance_mean']:>8.4f} (+/- {row['importance_std']:.4f})")
