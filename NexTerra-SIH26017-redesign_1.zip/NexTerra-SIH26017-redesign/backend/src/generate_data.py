# pyright: basic
"""
NexTerra Synthetic Data Generator
Under RFCTLARR Act, 2013 (Right to Fair Compensation and Transparency
in Land Acquisition, Rehabilitation and Resettlement Act, 2013).

Generates domain-accurate land acquisition data respecting:
1. Strict sequential statutory stages (Preliminary Notification -> SIA -> Declaration ->
   Expert Group -> Award -> Disbursement -> Possession).
2. Zero data leakage: No compensation disputes/delays before Stage 5 (Section 23/25 Award).
3. Stage 1 previous delay is strictly 0.
4. Chronological case ages reflecting actual real-world acquisition life-cycles (1 to 3+ years).
5. Real Indian administrative districts mapped to official LGD codes and GIS coordinates.
6. Linear infrastructure project corridors (SIH 26017 requirement).
7. Section 25 Statutory Lapse Risk (12-month statutory deadline from Section 19 Declaration).
"""

import random
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "nexterra_land_acquisition_8000_redesigned_v2.csv"

# Set deterministic random seeds for full reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

STAGE_CONFIG = [
    {
        "index": 1,
        "name": "Preliminary Notification",
        "median_ref": 45,
        "allowed_litigation": [
            "No Litigation",
            "Procedural / Administrative",
            "Land Ownership / Title",
        ],
        "allowed_objections": [
            "No Objection",
            "Land Use / Project Impact",
            "Land Measurement / Boundary Dispute",
            "Documentation / Procedural Objection",
        ],
        "allows_compensation_dispute": False,
        "typical_in_stage_days": (15, 75),
    },
    {
        "index": 2,
        "name": "Social Impact Assessment",
        "median_ref": 60,
        "allowed_litigation": [
            "No Litigation",
            "Procedural / Administrative",
            "Land Ownership / Title",
            "Rehabilitation & Resettlement",
        ],
        "allowed_objections": [
            "No Objection",
            "Rehabilitation & Resettlement",
            "Land Use / Project Impact",
            "Documentation / Procedural Objection",
        ],
        "allows_compensation_dispute": False,
        "typical_in_stage_days": (20, 100),
    },
    {
        "index": 3,
        "name": "Declaration & Survey",
        "median_ref": 55,
        "allowed_litigation": [
            "No Litigation",
            "Land Ownership / Title",
            "Procedural / Administrative",
            "Rehabilitation & Resettlement",
        ],
        "allowed_objections": [
            "No Objection",
            "Land Ownership / Title Dispute",
            "Land Measurement / Boundary Dispute",
            "Documentation / Procedural Objection",
        ],
        "allows_compensation_dispute": False,
        "typical_in_stage_days": (20, 95),
    },
    {
        "index": 4,
        "name": "Expert Group Review",
        "median_ref": 40,
        "allowed_litigation": [
            "No Litigation",
            "Procedural / Administrative",
            "Rehabilitation & Resettlement",
        ],
        "allowed_objections": [
            "No Objection",
            "Rehabilitation & Resettlement",
            "Documentation / Procedural Objection",
        ],
        "allows_compensation_dispute": False,
        "typical_in_stage_days": (15, 65),
    },
    {
        "index": 5,
        "name": "Award (Compensation Determination)",
        "median_ref": 65,
        "allowed_litigation": [
            "No Litigation",
            "Compensation / Valuation",
            "Land Ownership / Title",
            "Rehabilitation & Resettlement",
            "Procedural / Administrative",
        ],
        "allowed_objections": [
            "No Objection",
            "Compensation Dispute",
            "Land Ownership / Title Dispute",
            "Rehabilitation & Resettlement",
            "Land Measurement / Boundary Dispute",
        ],
        "allows_compensation_dispute": True,
        "typical_in_stage_days": (30, 130),
    },
    {
        "index": 6,
        "name": "Compensation Disbursement",
        "median_ref": 55,
        "allowed_litigation": [
            "No Litigation",
            "Compensation / Valuation",
            "Land Ownership / Title",
            "Procedural / Administrative",
        ],
        "allowed_objections": [
            "No Objection",
            "Compensation Dispute",
            "Land Ownership / Title Dispute",
            "Documentation / Procedural Objection",
        ],
        "allows_compensation_dispute": True,
        "typical_in_stage_days": (25, 110),
    },
    {
        "index": 7,
        "name": "Possession",
        "median_ref": 45,
        "allowed_litigation": [
            "No Litigation",
            "Land Ownership / Title",
            "Procedural / Administrative",
            "Compensation / Valuation",
        ],
        "allowed_objections": [
            "No Objection",
            "Land Measurement / Boundary Dispute",
            "Documentation / Procedural Objection",
            "Compensation Dispute",
        ],
        "allows_compensation_dispute": True,
        "typical_in_stage_days": (20, 90),
    },
]

# Real administrative districts mapped to official LGD codes and coordinates
DISTRICT_DATABASE = {
    "Maharashtra": [
        {"district": "Pune", "lgd": 490, "lat": 18.5204, "lon": 73.8567},
        {"district": "Nagpur", "lgd": 486, "lat": 21.1458, "lon": 79.0882},
        {"district": "Nashik", "lgd": 487, "lat": 19.9975, "lon": 73.7898},
        {"district": "Chhatrapati Sambhaji Nagar", "lgd": 467, "lat": 19.8762, "lon": 75.3433},
        {"district": "Thane", "lgd": 496, "lat": 19.2183, "lon": 72.9781},
        {"district": "Solapur", "lgd": 495, "lat": 17.6599, "lon": 75.9064},
    ],
    "Uttar Pradesh": [
        {"district": "Agra", "lgd": 128, "lat": 27.1767, "lon": 78.0081},
        {"district": "Lucknow", "lgd": 157, "lat": 26.8467, "lon": 80.9462},
        {"district": "Varanasi", "lgd": 175, "lat": 25.3176, "lon": 82.9739},
        {"district": "Kanpur Nagar", "lgd": 154, "lat": 26.4499, "lon": 80.3319},
        {"district": "Prayagraj", "lgd": 129, "lat": 25.4358, "lon": 81.8463},
        {"district": "Gorakhpur", "lgd": 148, "lat": 26.7606, "lon": 83.3732},
    ],
    "Rajasthan": [
        {"district": "Jaipur", "lgd": 105, "lat": 26.9124, "lon": 75.7873},
        {"district": "Jodhpur", "lgd": 107, "lat": 26.2389, "lon": 73.0243},
        {"district": "Udaipur", "lgd": 117, "lat": 24.5854, "lon": 73.7125},
        {"district": "Kota", "lgd": 109, "lat": 25.2138, "lon": 75.8648},
        {"district": "Ajmer", "lgd": 94, "lat": 26.4499, "lon": 74.6399},
        {"district": "Alwar", "lgd": 95, "lat": 27.5530, "lon": 76.6346},
    ],
    "Gujarat": [
        {"district": "Ahmedabad", "lgd": 440, "lat": 23.0225, "lon": 72.5714},
        {"district": "Surat", "lgd": 460, "lat": 21.1702, "lon": 72.8311},
        {"district": "Vadodara", "lgd": 462, "lat": 22.3072, "lon": 73.1812},
        {"district": "Rajkot", "lgd": 458, "lat": 22.3039, "lon": 70.8022},
        {"district": "Bharuch", "lgd": 444, "lat": 21.7051, "lon": 72.9959},
    ],
    "Madhya Pradesh": [
        {"district": "Bhopal", "lgd": 392, "lat": 23.2599, "lon": 77.4126},
        {"district": "Indore", "lgd": 405, "lat": 22.7196, "lon": 75.8577},
        {"district": "Jabalpur", "lgd": 406, "lat": 23.1815, "lon": 79.9864},
        {"district": "Gwalior", "lgd": 403, "lat": 26.2183, "lon": 78.1828},
        {"district": "Ujjain", "lgd": 424, "lat": 23.1765, "lon": 75.7885},
    ],
    "Punjab": [
        {"district": "Ludhiana", "lgd": 33, "lat": 30.9010, "lon": 75.8573},
        {"district": "Amritsar", "lgd": 24, "lat": 31.6340, "lon": 74.8723},
        {"district": "Jalandhar", "lgd": 30, "lat": 31.3260, "lon": 75.5762},
        {"district": "Patiala", "lgd": 35, "lat": 30.3398, "lon": 76.3869},
        {"district": "Bathinda", "lgd": 26, "lat": 30.2110, "lon": 74.9455},
    ],
    "Karnataka": [
        {"district": "Bengaluru Urban", "lgd": 524, "lat": 12.9716, "lon": 77.5946},
        {"district": "Mysuru", "lgd": 545, "lat": 12.2958, "lon": 76.6394},
        {"district": "Belagavi", "lgd": 525, "lat": 15.8497, "lon": 74.4977},
        {"district": "Hubballi-Dharwad", "lgd": 538, "lat": 15.3647, "lon": 75.1240},
        {"district": "Mangaluru", "lgd": 537, "lat": 12.9141, "lon": 74.8560},
    ],
    "Tamil Nadu": [
        {"district": "Chennai", "lgd": 565, "lat": 13.0827, "lon": 80.2707},
        {"district": "Coimbatore", "lgd": 566, "lat": 11.0168, "lon": 76.9558},
        {"district": "Madurai", "lgd": 577, "lat": 9.9252, "lon": 78.1198},
        {"district": "Salem", "lgd": 585, "lat": 11.6643, "lon": 78.1460},
        {"district": "Tiruchirappalli", "lgd": 591, "lat": 10.7905, "lon": 78.7047},
    ],
    "Andhra Pradesh": [
        {"district": "Visakhapatnam", "lgd": 519, "lat": 17.6868, "lon": 83.2185},
        {"district": "NTR Vijayawada", "lgd": 510, "lat": 16.5062, "lon": 80.6480},
        {"district": "Guntur", "lgd": 506, "lat": 16.3067, "lon": 80.4365},
        {"district": "Tirupati", "lgd": 504, "lat": 13.6288, "lon": 79.4192},
        {"district": "Kurnool", "lgd": 511, "lat": 15.8281, "lon": 78.0373},
    ],
    "West Bengal": [
        {"district": "Kolkata", "lgd": 314, "lat": 22.5726, "lon": 88.3639},
        {"district": "Howrah", "lgd": 310, "lat": 22.5958, "lon": 88.2636},
        {"district": "Purba Bardhaman", "lgd": 303, "lat": 23.2324, "lon": 87.8615},
        {"district": "Darjeeling", "lgd": 306, "lat": 26.7271, "lon": 88.3953},
    ],
    "Bihar": [
        {"district": "Patna", "lgd": 220, "lat": 25.5941, "lon": 85.1376},
        {"district": "Gaya", "lgd": 214, "lat": 24.7914, "lon": 85.0002},
        {"district": "Muzaffarpur", "lgd": 224, "lat": 26.1209, "lon": 85.3647},
        {"district": "Bhagalpur", "lgd": 208, "lat": 25.2425, "lon": 86.9842},
    ],
    "Haryana": [
        {"district": "Gurugram", "lgd": 70, "lat": 28.4595, "lon": 77.0266},
        {"district": "Faridabad", "lgd": 68, "lat": 28.4089, "lon": 77.3178},
        {"district": "Panipat", "lgd": 80, "lat": 29.3909, "lon": 76.9635},
        {"district": "Ambala", "lgd": 64, "lat": 30.3782, "lon": 76.7767},
    ],
    "Chhattisgarh": [
        {"district": "Raipur", "lgd": 382, "lat": 21.2514, "lon": 81.6296},
        {"district": "Bilaspur", "lgd": 375, "lat": 22.0797, "lon": 82.1409},
        {"district": "Durg", "lgd": 377, "lat": 21.1904, "lon": 81.2849},
    ],
}

LAND_TYPES = ["Agricultural", "Residential", "Industrial", "Commercial"]
LAND_TYPE_WEIGHTS = [0.55, 0.20, 0.15, 0.10]

PROJECT_TYPES = [
    "Highway",
    "Industrial Corridor",
    "Railway Line",
    "Power Transmission",
    "Irrigation Canal",
]

PROJECT_CORRIDORS = {
    "Highway": ["NH-48-EXP", "DEL-MUM-EWAY", "MAHA-SAMRUDDHI", "BHARATMALA-IC"],
    "Industrial Corridor": ["DMIC-NODE", "CBIC-NODE", "AKIC-NODE", "NICDIT-HUB"],
    "Railway Line": ["DFC-WEST", "DFC-EAST", "RRTS-DEL-MEERUT", "HSR-MUM-AHM"],
    "Power Transmission": ["GEC-PHASE2", "HVDC-RAIGARH-PUG", "NORTH-GRID-LINK"],
    "Irrigation Canal": ["KEN-BETWA-CANAL", "POLAVARAM-LINK", "NARMADA-BRANCH"],
}


def generate_synthetic_dataset(num_records: int = 8000) -> pd.DataFrame:
    records = []
    all_states = list(DISTRICT_DATABASE.keys())

    for idx in range(1, num_records + 1):
        case_id = f"LA{idx:05d}"

        # 1. Geography & Linear Alignment
        state = random.choice(all_states)
        dist_meta = random.choice(DISTRICT_DATABASE[state])
        district = dist_meta["district"]
        district_lgd_code = dist_meta["lgd"]
        # Add slight jitter (+/- 0.08 deg) to represent distinct land parcels within the district
        latitude = round(dist_meta["lat"] + np.random.uniform(-0.06, 0.06), 4)
        longitude = round(dist_meta["lon"] + np.random.uniform(-0.06, 0.06), 4)

        # 2. Project & Land Profile
        project_type = random.choice(PROJECT_TYPES)
        corridor_id = random.choice(PROJECT_CORRIDORS[project_type])
        land_type = random.choices(LAND_TYPES, weights=LAND_TYPE_WEIGHTS, k=1)[0]

        # Land area and landowners (correlated with land type)
        if land_type == "Agricultural":
            land_area_hectares = round(float(np.random.gamma(shape=2.5, scale=4.0)), 2)
            land_area_hectares = max(0.5, min(120.0, land_area_hectares))
            number_of_landowners = int(max(1, np.random.poisson(lam=land_area_hectares * 2.8 + 5)))
        elif land_type == "Residential":
            land_area_hectares = round(float(np.random.gamma(shape=1.5, scale=1.5)), 2)
            land_area_hectares = max(0.1, min(25.0, land_area_hectares))
            number_of_landowners = int(max(1, np.random.poisson(lam=land_area_hectares * 6.0 + 8)))
        elif land_type == "Industrial":
            land_area_hectares = round(float(np.random.gamma(shape=2.0, scale=6.0)), 2)
            land_area_hectares = max(0.8, min(150.0, land_area_hectares))
            number_of_landowners = int(max(1, np.random.poisson(lam=land_area_hectares * 0.9 + 3)))
        else:  # Commercial
            land_area_hectares = round(float(np.random.gamma(shape=1.2, scale=2.5)), 2)
            land_area_hectares = max(0.2, min(40.0, land_area_hectares))
            number_of_landowners = int(max(1, np.random.poisson(lam=land_area_hectares * 4.0 + 6)))

        # 3. Stage Simulation following RFCTLARR Act sequential lifecycle
        # Distribute cases realistically across active stages
        stage_cfg = random.choice(STAGE_CONFIG)
        stage_idx = stage_cfg["index"]
        acquisition_stage = stage_cfg["name"]
        stage_median_days_reference = stage_cfg["median_ref"]

        # Days in current stage
        min_in, max_in = stage_cfg["typical_in_stage_days"]
        days_in_stage = int(np.random.triangular(left=min_in, mode=stage_median_days_reference, right=max_in))

        # Historical Stage Simulation: Accumulate prior stage durations and delays
        # Stage 1 has ZERO prior stages and ZERO prior delays!
        historical_durations = []
        historical_delays = []

        if stage_idx == 1:
            previous_stage_delay_days = 0
            case_age_days = days_in_stage
        else:
            for past_idx in range(1, stage_idx):
                past_stage_meta = STAGE_CONFIG[past_idx - 1]
                past_ref = past_stage_meta["median_ref"]
                # 70% of historical stages had mild/no delay; 30% had moderate delay
                if np.random.rand() < 0.70:
                    past_delay = int(np.random.exponential(scale=5.0))
                else:
                    past_delay = int(np.random.gamma(shape=2.0, scale=10.0))
                past_duration = past_ref + past_delay
                historical_durations.append(past_duration)
                historical_delays.append(past_delay)

            previous_stage_delay_days = sum(historical_delays)
            case_age_days = sum(historical_durations) + days_in_stage

        # 4. Compensation Disputes & Delays (Legally impossible in stages 1 to 4)
        if not stage_cfg["allows_compensation_dispute"]:
            compensation_disputed = 0
            compensation_delay_days = 0
        else:
            # Stage 5, 6, 7: Compensation awards occur
            # ~30% of cases face valuation disputes
            is_disputed = 1 if np.random.rand() < 0.32 else 0
            compensation_disputed = is_disputed
            if is_disputed:
                compensation_delay_days = int(np.random.gamma(shape=2.5, scale=16.0)) + 15
            else:
                compensation_delay_days = int(np.random.exponential(scale=4.0)) if np.random.rand() < 0.25 else 0

        # 5. Litigation & Objections (Restricted to legally valid categories per stage)
        litigation_prob = 0.35 if stage_idx >= 5 else (0.22 if stage_idx >= 3 else 0.12)
        if np.random.rand() < litigation_prob:
            lit_candidates = [
                c for c in stage_cfg["allowed_litigation"] if c != "No Litigation"
            ]
            litigation_type = random.choice(lit_candidates) if lit_candidates else "No Litigation"
            litigation_present = 1
        else:
            litigation_type = "No Litigation"
            litigation_present = 0

        obj_prob = 0.40 if stage_idx in [2, 3, 5] else 0.20
        if np.random.rand() < obj_prob:
            obj_candidates = [
                c for c in stage_cfg["allowed_objections"] if c != "No Objection"
            ]
            objection_category = random.choice(obj_candidates) if obj_candidates else "No Objection"
            objection_present = 1
            number_of_objections = int(np.random.poisson(lam=3.5)) + 1
        else:
            objection_category = "No Objection"
            objection_present = 0
            number_of_objections = 0

        # 6. Documentation Completeness & Historical Jurisdiction Performance
        # Earlier stages tend to have lower initial completion; later stages are near complete
        base_doc = 70.0 + (stage_idx * 4.0)
        documentation_completeness_pct = round(
            float(np.clip(np.random.normal(loc=base_doc, scale=12.0), 30.0, 100.0)),
            1,
        )

        # Historical delay rate of the district SLAO / revenue wing (0.04 to 0.45)
        # Seeded by state/district baseline
        state_seed = abs(hash(state)) % 100 / 1000.0 + 0.08
        dist_seed = abs(hash(district)) % 50 / 1000.0
        historical_delay_rate = round(
            float(np.clip(state_seed + dist_seed + np.random.normal(0, 0.03), 0.03, 0.42)),
            3,
        )

        # 7. Domain-Aware Ground-Truth Delay Calculation
        # Modeled on real land acquisition friction factors:
        # a. Current stage backlog: days in stage exceeding reference duration
        stage_friction = max(0, days_in_stage - stage_median_days_reference) * 0.72

        # b. Previous stage cumulative inertia
        inertia_delay = previous_stage_delay_days * 0.42

        # c. Litigation delay impact
        lit_delay = 0.0
        if litigation_present:
            if litigation_type == "Compensation / Valuation":
                lit_delay = 55.0 + np.random.uniform(5, 30)
            elif litigation_type == "Land Ownership / Title":
                lit_delay = 45.0 + np.random.uniform(5, 25)
            elif litigation_type == "Rehabilitation & Resettlement":
                lit_delay = 40.0 + np.random.uniform(5, 20)
            else:  # Procedural
                lit_delay = 25.0 + np.random.uniform(2, 15)

        # d. Objections delay impact
        obj_delay = 0.0
        if objection_present:
            obj_delay = min(40.0, number_of_objections * 6.5)

        # e. Compensation friction (only stages >= 5)
        comp_delay = 0.0
        if compensation_disputed:
            comp_delay = 28.0 + (compensation_delay_days * 0.48)
        else:
            comp_delay = compensation_delay_days * 0.35

        # f. Documentation deficit impact: missing documents add verification time
        doc_deficit = (100.0 - documentation_completeness_pct) * 0.55

        # g. Scale complexities (landowners and area)
        scale_complexity = (np.log1p(number_of_landowners) * 7.0) + (np.sqrt(land_area_hectares) * 3.2)

        # h. Jurisdictional drag
        jurisdiction_drag = historical_delay_rate * 55.0

        # Total expected additional delay with realistic variance
        total_delay_raw = (
            stage_friction
            + inertia_delay
            + lit_delay
            + obj_delay
            + comp_delay
            + doc_deficit
            + scale_complexity
            + jurisdiction_drag
            + np.random.normal(0, 6.0)
        )
        final_additional_delay_days = int(max(0, round(total_delay_raw)))

        # 8. Statutory Lapse Target under Section 25 of RFCTLARR Act:
        # If Section 19 Declaration is published, Award must be published within 365 days.
        # Compute elapsed time since Section 19 Declaration:
        # In stage 3 (Declaration), days elapsed = days_in_stage
        # In stage 4 (Expert Group), days elapsed = stage 3 duration + days_in_stage
        # In stage 5 (Award), days elapsed = stage 3 duration + stage 4 duration + days_in_stage
        if stage_idx in [3, 4, 5]:
            if stage_idx == 3:
                elapsed_sec19 = days_in_stage
            elif stage_idx == 4:
                elapsed_sec19 = (STAGE_CONFIG[2]["median_ref"] + historical_delays[-1] if historical_delays else 55) + days_in_stage
            else: # stage 5
                # stages 3 and 4 duration
                past_3_dur = STAGE_CONFIG[2]["median_ref"] + (historical_delays[-2] if len(historical_delays) >= 2 else 10)
                past_4_dur = STAGE_CONFIG[3]["median_ref"] + (historical_delays[-1] if historical_delays else 5)
                elapsed_sec19 = past_3_dur + past_4_dur + days_in_stage

            projected_sec19_to_award = elapsed_sec19 + final_additional_delay_days
            statutory_lapse_risk = 1 if projected_sec19_to_award > 365 else 0
        else:
            # For stages before sec 19 or after award: based on severe projected delay exceeding statutory envelope
            statutory_lapse_risk = 1 if final_additional_delay_days > 150 else 0

        records.append({
            "case_id": case_id,
            "state": state,
            "district": district,
            "district_lgd_code": district_lgd_code,
            "latitude": latitude,
            "longitude": longitude,
            "corridor_id": corridor_id,
            "land_type": land_type,
            "project_type": project_type,
            "acquisition_stage": acquisition_stage,
            "stage_median_days_reference": stage_median_days_reference,
            "case_age_days": case_age_days,
            "days_in_stage": days_in_stage,
            "number_of_landowners": number_of_landowners,
            "land_area_hectares": land_area_hectares,
            "litigation_present": litigation_present,
            "litigation_type": litigation_type,
            "objection_present": objection_present,
            "objection_category": objection_category,
            "number_of_objections": number_of_objections,
            "compensation_disputed": compensation_disputed,
            "compensation_delay_days": compensation_delay_days,
            "documentation_completeness_pct": documentation_completeness_pct,
            "previous_stage_delay_days": previous_stage_delay_days,
            "historical_delay_rate": historical_delay_rate,
            "statutory_lapse_risk": statutory_lapse_risk,
            "final_additional_delay_days": final_additional_delay_days,
        })

    df = pd.DataFrame(records)
    return df


def validate_domain_rules(df: pd.DataFrame) -> None:
    """Validate that the dataset satisfies all legal and procedural invariants."""
    print("Validating legal & procedural invariants...")

    # Invariant 1: Stage 1 has strictly 0 previous_stage_delay_days
    stg1 = df[df["acquisition_stage"] == "Preliminary Notification"]
    stg1_prev_delays = (stg1["previous_stage_delay_days"] > 0).sum()
    assert stg1_prev_delays == 0, f"Violation: {stg1_prev_delays} Stage 1 cases have previous delay > 0!"

    # Invariant 2: Stages 1-4 have strictly 0 compensation_disputed and 0 compensation_delay_days
    early_stages = [
        "Preliminary Notification",
        "Social Impact Assessment",
        "Declaration & Survey",
        "Expert Group Review",
    ]
    early_df = df[df["acquisition_stage"].isin(early_stages)]
    comp_disputes = (early_df["compensation_disputed"] > 0).sum()
    comp_delays = (early_df["compensation_delay_days"] > 0).sum()
    assert comp_disputes == 0, f"Violation: {comp_disputes} early stage cases have compensation disputed!"
    assert comp_delays == 0, f"Violation: {comp_delays} early stage cases have compensation delays!"

    # Invariant 3: Case age is monotonically increasing across legal sequence
    mean_ages = df.groupby("acquisition_stage")["case_age_days"].mean()
    print("\nMean Case Age by Statutory Stage:")
    for stage_cfg in STAGE_CONFIG:
        name = stage_cfg["name"]
        print(f"  Stage {stage_cfg['index']} [{name:<35}]: {mean_ages.get(name, 0):.1f} days")

    stg1_age = mean_ages["Preliminary Notification"]
    stg7_age = mean_ages["Possession"]
    assert stg7_age > stg1_age * 5, (
        f"Violation: Stage 7 age ({stg7_age:.1f}) must be substantially larger than Stage 1 ({stg1_age:.1f})"
    )

    # Invariant 4: No placeholder districts
    placeholder_count = df["district"].str.contains("District [0-9]", regex=True).sum()
    assert placeholder_count == 0, f"Violation: Found {placeholder_count} placeholder districts!"

    # Invariant 5: GIS and linear corridor validity
    assert df["latitude"].notna().all() and df["longitude"].notna().all(), "Missing coordinates!"
    assert (df["corridor_id"].str.len() > 0).all(), "Missing corridor IDs!"

    print("\nAll statutory and domain invariants successfully passed!")


if __name__ == "__main__":
    print(f"Generating 8,000 domain-compliant cases under RFCTLARR Act 2013...")
    df = generate_synthetic_dataset(8000)
    validate_domain_rules(df)

    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(DATA_PATH, index=False)
    print(f"\nSaved {len(df)} cases to {DATA_PATH}")
