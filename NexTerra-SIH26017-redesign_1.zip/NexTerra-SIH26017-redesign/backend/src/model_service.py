# pyright: basic
"""
NexTerra Model Service
SIH 26017 - Decision Support & Simulation Engine

Features:
- Multi-Head predictions: P10 (best case), P50 (expected), P90 (worst case)
- Calibrated Section 25 Statutory Lapse Risk under RFCTLARR Act 2013
- Bidirectional SHAP explanations (Accelerators vs Protective Mitigators)
- "What-If" Counterfactual Simulation Engine (/api/simulate)
- GIS corridor analytics & mapping (/api/corridors, /api/gis/parcels)
- Resilient auto-derivation of redundant fields
"""

from pathlib import Path
import json
import sys
from typing import Any, Dict, List, Optional

# Ensure backend root is on sys.path
BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

import joblib
import numpy as np
import pandas as pd
import shap

from src.ensemble_pipeline import NexTerraEnsemblePipeline

MODEL_PATH = BASE_DIR / "models" / "nexterra_delay_model.pkl"
MODEL_REPORT_PATH = BASE_DIR / "models" / "model_validation.json"
DATA_PATH = BASE_DIR / "data" / "nexterra_land_acquisition_8000_redesigned_v2.csv"

STAGE_REFERENCE_DAYS = {
    "Preliminary Notification": 45,
    "Social Impact Assessment": 60,
    "Declaration & Survey": 55,
    "Expert Group Review": 40,
    "Award (Compensation Determination)": 65,
    "Compensation Disbursement": 55,
    "Possession": 45,
}

STAGE_SEQUENCE = [
    "Preliminary Notification",
    "Social Impact Assessment",
    "Declaration & Survey",
    "Expert Group Review",
    "Award (Compensation Determination)",
    "Compensation Disbursement",
    "Possession",
]

_pipeline: Optional[NexTerraEnsemblePipeline] = None
_explainer = None
_cases_df: Optional[pd.DataFrame] = None


def _load_model():
    """Load the trained ensemble pipeline and SHAP TreeExplainer lazily."""
    global _pipeline, _explainer

    if _pipeline is None:
        if not MODEL_PATH.is_file():
            raise FileNotFoundError(f"Model file not found at {MODEL_PATH}")

        _pipeline = joblib.load(MODEL_PATH)
        # Use TreeExplainer on the p50 HistGradientBoosting regressor
        _explainer = shap.TreeExplainer(_pipeline.p50_model)

    return _pipeline, _explainer


def risk_from_delay_and_lapse(predicted_delay: float, lapse_risk_pct: float) -> str:
    """
    Statutory-aware risk classification under RFCTLARR Act 2013.
    Integrates delay magnitude and statutory lapse probability.
    """
    if lapse_risk_pct >= 60.0 or predicted_delay >= 120.0:
        return "HIGH"
    elif lapse_risk_pct >= 25.0 or predicted_delay >= 60.0:
        return "MEDIUM"
    return "LOW"


def get_model_info():
    """Return model validation metrics and domain architecture specifications."""
    default = {
        "model_available": MODEL_PATH.is_file(),
        "validation_status": "not_available",
        "data_status": "domain_compliant_rfctlarr",
        "metrics": None,
        "message": (
            "NexTerra Multi-Head Gradient Boosting Engine. "
            "Trained under RFCTLARR Act statutory sequential constraints."
        ),
    }

    if not MODEL_REPORT_PATH.is_file():
        return default

    try:
        report = json.loads(MODEL_REPORT_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default

    return {
        **default,
        "validation_status": "state_group_holdout_generalized",
        "metrics": report,
        "message": (
            f"Evaluated on held-out states: {', '.join(report.get('held_out_states', []))}. "
            f"Test MAE: {report.get('model_mae_days')} days (vs {report.get('median_baseline_mae_days')} days median baseline)."
        ),
    }


FEATURE_LABELS = {
    "cat__litigation_type": "Litigation Status",
    "cat__objection_category": "Objection Category",
    "cat__acquisition_stage": "Acquisition Stage",
    "cat__district": "District Jurisdiction Pace",
    "cat__state": "State Administrative Pace",
    "cat__land_type": "Land Category",
    "cat__project_type": "Project Infrastructure Type",
    "num__stage_median_days_reference": "Stage Reference Duration",
    "num__case_age_days": "Cumulative Case Age",
    "num__days_in_stage": "Days in Current Stage",
    "num__number_of_landowners": "Landowner Count",
    "num__land_area_hectares": "Acquisition Land Area",
    "num__litigation_present": "Active Litigation Flag",
    "num__objection_present": "Active Objection Flag",
    "num__number_of_objections": "Volume of Formal Objections",
    "num__compensation_disputed": "Compensation Dispute Status",
    "num__compensation_delay_days": "Compensation Resolution Lag",
    "num__documentation_completeness_pct": "Documentation Completeness",
    "num__previous_stage_delay_days": "Prior Stages Accumulated Delay",
    "num__historical_delay_rate": "Jurisdiction Historical Delay Rate",
}


def _derive_missing_fields(case_data: Dict[str, Any]) -> Dict[str, Any]:
    """Auto-derive redundant or missing fields to eliminate API fragility."""
    d = dict(case_data)

    stage = d.get("acquisition_stage", "Preliminary Notification")
    if "stage_median_days_reference" not in d or d["stage_median_days_reference"] is None:
        d["stage_median_days_reference"] = STAGE_REFERENCE_DAYS.get(stage, 45)

    lit_type = d.get("litigation_type", "No Litigation")
    if "litigation_present" not in d or d["litigation_present"] is None:
        d["litigation_present"] = 0 if lit_type == "No Litigation" else 1

    obj_cat = d.get("objection_category", "No Objection")
    num_obj = d.get("number_of_objections", 0) or 0
    if "objection_present" not in d or d["objection_present"] is None:
        d["objection_present"] = 1 if (obj_cat != "No Objection" and num_obj > 0) else 0

    if "compensation_disputed" not in d or d["compensation_disputed"] is None:
        d["compensation_disputed"] = 0

    if "compensation_delay_days" not in d or d["compensation_delay_days"] is None:
        d["compensation_delay_days"] = 0

    if "previous_stage_delay_days" not in d or d["previous_stage_delay_days"] is None:
        d["previous_stage_delay_days"] = 0

    if "case_age_days" not in d or d["case_age_days"] is None or d["case_age_days"] == 0:
        # Realistic estimate based on completed stages
        stg_idx = STAGE_SEQUENCE.index(stage) if stage in STAGE_SEQUENCE else 0
        est_age = sum(STAGE_REFERENCE_DAYS[s] for s in STAGE_SEQUENCE[:stg_idx]) + d.get("days_in_stage", 30)
        d["case_age_days"] = est_age

    if "documentation_completeness_pct" not in d or d["documentation_completeness_pct"] is None:
        d["documentation_completeness_pct"] = 80.0

    if "number_of_landowners" not in d or d["number_of_landowners"] is None:
        d["number_of_landowners"] = 15

    if "land_area_hectares" not in d or d["land_area_hectares"] is None:
        d["land_area_hectares"] = 5.0

    if "days_in_stage" not in d or d["days_in_stage"] is None:
        d["days_in_stage"] = 30

    if "historical_delay_rate" not in d or d["historical_delay_rate"] is None:
        d["historical_delay_rate"] = 0.12

    return d


def _format_feature_description(feature_key: str, value: Any, impact: float, is_accelerator: bool) -> str:
    """Generate concise, actionable administrative rationale for SHAP factors."""
    direction = "adds" if is_accelerator else "reduces"
    days_str = f"{abs(impact):.1f} days"

    if "litigation_type" in feature_key:
        if str(value) != "No Litigation":
            return f"Active litigation under '{value}' introduces legal disputes and {direction} ~{days_str}."
        return f"Clean legal title with zero litigation expedites hearings, saving ~{days_str}."

    if "documentation_completeness" in feature_key:
        try:
            val_f = float(value)
        except (ValueError, TypeError):
            val_f = 80.0
        if val_f >= 90.0:
            return f"High documentation readiness ({val_f:.0f}%) accelerates verification, saving ~{days_str}."
        return f"Documentation deficit ({val_f:.0f}%) requires administrative rework, adding ~{days_str}."

    if "compensation" in feature_key:
        try:
            val_int = int(value)
        except (ValueError, TypeError):
            val_int = 0
        if "disputed" in feature_key and val_int == 1:
            return f"Contested valuation triggers enhanced hearing procedures, adding ~{days_str}."
        if "delay" in feature_key and val_int > 0:
            return f"Existing compensation disbursement backlog contributes ~{days_str}."
        return f"Undisputed compensation facilitates rapid disbursement, saving ~{days_str}."

    if "days_in_stage" in feature_key:
        return f"Case spent {value} days in current stage, which {direction} ~{days_str} against statutory schedule."

    if "previous_stage_delay" in feature_key:
        try:
            val_int = int(value)
        except (ValueError, TypeError):
            val_int = 0
        if val_int > 0:
            return f"Unresolved delays of {val_int} days from prior stages cascade forward, adding ~{days_str}."
        return f"Flawless progression through prior stages creates schedule headroom, saving ~{days_str}."

    if "number_of_landowners" in feature_key:
        return f"Coordination and notice service across {value} landowners {direction} ~{days_str}."

    if "number_of_objections" in feature_key:
        try:
            val_int = int(value)
        except (ValueError, TypeError):
            val_int = 0
        if val_int > 0:
            return f"Processing and hearing {val_int} formal objections adds ~{days_str}."
        return f"Zero formal objections received under Section 15, saving ~{days_str}."

    label = FEATURE_LABELS.get(feature_key, feature_key)
    return f"{label} ({value}) {direction} approximately {days_str} based on learned administrative patterns."


def predict_case(raw_case_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run multi-head prediction:
    - P10, P50, P90 Quantile bounds
    - Calibrated Section 25 Statutory Lapse Probability
    - Bidirectional SHAP (Accelerators vs Protective Mitigators)
    """
    pipeline, explainer = _load_model()
    case_data = _derive_missing_fields(raw_case_data)

    df_single = pd.DataFrame([case_data])

    # 1. Predictions
    predicted_delay = int(round(float(pipeline.predict(df_single)[0])))
    quantiles = pipeline.predict_quantiles(df_single)
    p10 = int(round(float(quantiles["p10"][0])))
    p50 = int(round(float(quantiles["p50"][0])))
    p90 = int(round(float(quantiles["p90"][0])))

    # 2. Section 25 Statutory Lapse Risk
    lapse_prob = float(pipeline.predict_lapse_probability(df_single)[0])
    lapse_risk_pct = round(lapse_prob * 100.0, 1)

    risk_level = risk_from_delay_and_lapse(predicted_delay, lapse_risk_pct)

    # Statutory Status & Alert Text
    if lapse_risk_pct >= 60.0:
        statutory_lapse_status = "CRITICAL RISK (Sec 25 RFCTLARR)"
        statutory_lapse_alert = (
            f"HIGH RISK ({lapse_risk_pct}%): Case exceeds statutory timeline thresholds. "
            "Under Section 25, Award must be published within 12 months from Declaration or acquisition lapses legally."
        )
    elif lapse_risk_pct >= 25.0:
        statutory_lapse_status = "MODERATE WATCH (Sec 25 RFCTLARR)"
        statutory_lapse_alert = (
            f"MODERATE WATCH ({lapse_risk_pct}%): Approaching statutory boundary. "
            "Monitor Joint Measurement Survey and SLAO award drafting closely."
        )
    else:
        statutory_lapse_status = "NOMINAL COMPLIANCE"
        statutory_lapse_alert = f"LOW RISK ({lapse_risk_pct}%): Acquisition timeline is within nominal statutory margins."

    # 3. Bidirectional SHAP Explanations
    X_trans = pipeline.transform(df_single)
    shap_values = explainer.shap_values(X_trans)
    if shap_values.ndim > 1:
        shap_values = shap_values[0]
    shap_values = shap_values.reshape(-1)

    feature_names = pipeline.preprocessor.get_feature_names_out()

    factors = []
    for f_name, s_val in zip(feature_names, shap_values):
        impact = float(s_val)
        if abs(impact) < 0.2:
            continue

        raw_col = f_name.replace("cat__", "").replace("num__", "")
        raw_val = case_data.get(raw_col, "N/A")
        label = FEATURE_LABELS.get(f_name, raw_col.replace("_", " ").title())

        factors.append({
            "feature_key": f_name,
            "feature": label,
            "raw_column": raw_col,
            "value": raw_val,
            "impact_days": round(impact, 2),
            "is_accelerator": impact > 0,
        })

    # Separate Accelerators (+ delay) and Mitigators (- delay)
    accelerators_raw = [f for f in factors if f["impact_days"] > 0]
    mitigators_raw = [f for f in factors if f["impact_days"] < 0]

    accelerators_raw.sort(key=lambda x: x["impact_days"], reverse=True)
    mitigators_raw.sort(key=lambda x: x["impact_days"])  # most negative first

    accelerators = []
    for item in accelerators_raw[:4]:
        item["reason"] = _format_feature_description(
            item["feature_key"], item["value"], item["impact_days"], True
        )
        accelerators.append(item)

    mitigators = []
    for item in mitigators_raw[:4]:
        item["reason"] = _format_feature_description(
            item["feature_key"], item["value"], item["impact_days"], False
        )
        mitigators.append(item)

    # Backward compatibility: 'reasons' list for legacy UI
    reasons = []
    for item in accelerators[:3]:
        reasons.append({
            "feature": item["feature"],
            "value": item["value"],
            "impact_days": round(item["impact_days"], 1),
            "reason": item["reason"],
            "type": "accelerator",
        })
    for item in mitigators[:2]:
        reasons.append({
            "feature": item["feature"],
            "value": item["value"],
            "impact_days": round(item["impact_days"], 1),
            "reason": item["reason"],
            "type": "mitigator",
        })

    return {
        "predicted_additional_delay_days": predicted_delay,
        "risk_level": risk_level,
        "quantiles": {
            "p10_best_case": p10,
            "p50_expected": p50,
            "p90_worst_case": p90,
        },
        "statutory_lapse_risk_pct": lapse_risk_pct,
        "statutory_lapse_status": statutory_lapse_status,
        "statutory_lapse_alert": statutory_lapse_alert,
        "risk_accelerators": accelerators,
        "protective_mitigators": mitigators,
        "reasons": reasons,
    }


def simulate_counterfactual(
    base_case_data: Dict[str, Any],
    modifications: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Interactive 'What-If' Counterfactual Simulation Engine.
    Evaluates administrative interventions (e.g. fast-track survey, dispute settlement)
    and computes net days saved and statutory lapse risk reduction.
    """
    baseline_result = predict_case(base_case_data)
    simulated_case_data = dict(base_case_data)

    interventions_applied = []

    # Apply targeted interventions
    if modifications.get("fast_track_survey") or "days_in_stage" in modifications:
        new_days = int(modifications.get("days_in_stage", 15))
        old_days = simulated_case_data.get("days_in_stage", 45)
        simulated_case_data["days_in_stage"] = new_days
        interventions_applied.append(f"Fast-track survey: reduced days in stage from {old_days} to {new_days} days")

    if modifications.get("resolve_litigation") or modifications.get("litigation_type") == "No Litigation":
        old_lit = simulated_case_data.get("litigation_type", "Active")
        simulated_case_data["litigation_type"] = "No Litigation"
        simulated_case_data["litigation_present"] = 0
        interventions_applied.append(f"Settled pending litigation ('{old_lit}' -> 'No Litigation')")

    if modifications.get("resolve_compensation_dispute") or modifications.get("compensation_disputed") == 0:
        simulated_case_data["compensation_disputed"] = 0
        simulated_case_data["compensation_delay_days"] = 0
        interventions_applied.append("Resolved compensation dispute through Special Land Acquisition Lok Adalat")

    if modifications.get("resolve_objections") or modifications.get("number_of_objections") == 0:
        simulated_case_data["objection_category"] = "No Objection"
        simulated_case_data["objection_present"] = 0
        simulated_case_data["number_of_objections"] = 0
        interventions_applied.append("Disposed all Section 15 objections via joint hearing")

    if "documentation_completeness_pct" in modifications or modifications.get("complete_documentation"):
        target_doc = float(modifications.get("documentation_completeness_pct", 100.0))
        old_doc = simulated_case_data.get("documentation_completeness_pct", 80.0)
        simulated_case_data["documentation_completeness_pct"] = target_doc
        interventions_applied.append(f"Expedited documentation completeness ({old_doc:.0f}% -> {target_doc:.0f}%)")

    simulated_result = predict_case(simulated_case_data)

    base_p50 = baseline_result["predicted_additional_delay_days"]
    sim_p50 = simulated_result["predicted_additional_delay_days"]
    net_days_saved = max(0, base_p50 - sim_p50)

    base_lapse = baseline_result["statutory_lapse_risk_pct"]
    sim_lapse = simulated_result["statutory_lapse_risk_pct"]
    lapse_risk_reduction_pct = round(max(0.0, base_lapse - sim_lapse), 1)

    pct_time_saved = round((net_days_saved / base_p50 * 100.0), 1) if base_p50 > 0 else 0.0

    return {
        "baseline": {
            "predicted_additional_delay_days": base_p50,
            "quantiles": baseline_result["quantiles"],
            "risk_level": baseline_result["risk_level"],
            "statutory_lapse_risk_pct": base_lapse,
        },
        "simulated": {
            "predicted_additional_delay_days": sim_p50,
            "quantiles": simulated_result["quantiles"],
            "risk_level": simulated_result["risk_level"],
            "statutory_lapse_risk_pct": sim_lapse,
        },
        "impact_summary": {
            "net_days_saved": net_days_saved,
            "pct_delay_reduction": pct_time_saved,
            "statutory_lapse_risk_reduction_pct": lapse_risk_reduction_pct,
            "interventions_applied": interventions_applied,
        },
        "recommendation": (
            f"Applying {len(interventions_applied)} administrative interventions saves {net_days_saved} days "
            f"({pct_time_saved}% reduction) and reduces Section 25 statutory lapse risk by {lapse_risk_reduction_pct}%. "
            "Prioritize Lok Adalat settlement and title verification."
        ),
    }


# ==========================================
# Bulk Dataset, GIS & Corridor Analytics
# ==========================================

_FEATURE_COLUMNS = [
    "state",
    "district",
    "land_type",
    "project_type",
    "acquisition_stage",
    "stage_median_days_reference",
    "case_age_days",
    "days_in_stage",
    "number_of_landowners",
    "land_area_hectares",
    "litigation_present",
    "litigation_type",
    "objection_present",
    "objection_category",
    "number_of_objections",
    "compensation_disputed",
    "compensation_delay_days",
    "documentation_completeness_pct",
    "previous_stage_delay_days",
    "historical_delay_rate",
]


def load_cases() -> pd.DataFrame:
    """Load dataset once, compute vectorized predictions and cache in memory."""
    global _cases_df

    pipeline, _ = _load_model()

    if not DATA_PATH.is_file():
        raise FileNotFoundError(f"Data file not found at {DATA_PATH}")

    df = pd.read_csv(DATA_PATH)

    # Vectorized multi-head predictions
    preds = pipeline.predict(df[_FEATURE_COLUMNS])
    quantiles = pipeline.predict_quantiles(df[_FEATURE_COLUMNS])
    lapse_probs = pipeline.predict_lapse_probability(df[_FEATURE_COLUMNS])

    df["predicted_additional_delay_days"] = np.round(preds).astype(int)
    df["p10_delay_days"] = quantiles["p10"].astype(int)
    df["p50_delay_days"] = quantiles["p50"].astype(int)
    df["p90_delay_days"] = quantiles["p90"].astype(int)
    df["statutory_lapse_risk_pct"] = np.round(lapse_probs * 100.0, 1)

    df["risk_level"] = [
        risk_from_delay_and_lapse(d, l)
        for d, l in zip(df["predicted_additional_delay_days"], df["statutory_lapse_risk_pct"])
    ]

    _cases_df = df
    return _cases_df


def get_cases(
    state: Optional[str] = None,
    land_type: Optional[str] = None,
    acquisition_stage: Optional[str] = None,
    risk_level: Optional[str] = None,
    corridor_id: Optional[str] = None,
    limit: Any = 50,
    offset: Any = 0,
) -> Dict[str, Any]:
    """Return filtered, paginated cases with multi-head predictions and GIS fields."""
    if _cases_df is None:
        load_cases()

    df = _cases_df
    assert df is not None

    if state:
        df = df[df["state"].str.lower() == state.lower()]
    if land_type:
        df = df[df["land_type"].str.lower() == land_type.lower()]
    if acquisition_stage:
        df = df[df["acquisition_stage"].str.lower() == acquisition_stage.lower()]
    if risk_level:
        df = df[df["risk_level"].str.upper() == risk_level.upper()]
    if corridor_id:
        df = df[df["corridor_id"].str.lower() == corridor_id.lower()]

    lim = int(getattr(limit, "default", limit))
    off = int(getattr(offset, "default", offset))
    total = len(df)
    page = df.iloc[off : off + lim]

    columns = [
        "case_id",
        "state",
        "district",
        "corridor_id",
        "latitude",
        "longitude",
        "land_type",
        "project_type",
        "acquisition_stage",
        "days_in_stage",
        "litigation_present",
        "litigation_type",
        "objection_category",
        "predicted_additional_delay_days",
        "p10_delay_days",
        "p90_delay_days",
        "statutory_lapse_risk_pct",
        "risk_level",
    ]

    available_cols = [c for c in columns if c in page.columns]
    return {
        "total": int(total),
        "limit": limit,
        "offset": offset,
        "cases": page[available_cols].to_dict(orient="records"),
    }


def get_case_by_id(case_id: str) -> Optional[Dict[str, Any]]:
    """Return single dataset case with multi-head prediction and bidirectional SHAP."""
    if _cases_df is None:
        load_cases()

    assert _cases_df is not None
    match = _cases_df[_cases_df["case_id"] == case_id]
    if match.empty:
        return None

    row = match.iloc[0]
    case_data = {
        col: (row[col].item() if hasattr(row[col], "item") else row[col])
        for col in _FEATURE_COLUMNS
    }

    result = predict_case(case_data)
    # Retain all original attributes for frontend and simulation
    for col in _FEATURE_COLUMNS:
        result[col] = case_data[col]

    result["case_id"] = str(case_id)
    result["corridor_id"] = str(row.get("corridor_id", "CORRIDOR-GEN"))
    result["latitude"] = float(row.get("latitude", 20.5937))
    result["longitude"] = float(row.get("longitude", 78.9629))
    return result


def get_corridor_summary() -> List[Dict[str, Any]]:
    """Aggregate project corridors for GIS map visualization (SIH 26017 requirement)."""
    if _cases_df is None:
        load_cases()

    assert _cases_df is not None
    df = _cases_df

    if "corridor_id" not in df.columns:
        return []

    corridors = []
    for corridor_id, group in df.groupby("corridor_id"):
        high_risk_count = int((group["risk_level"] == "HIGH").sum())
        total_parcels = int(len(group))
        avg_delay = round(float(group["predicted_additional_delay_days"].mean()), 1)
        avg_lapse = round(float(group["statutory_lapse_risk_pct"].mean()), 1)
        mean_lat = round(float(group["latitude"].mean()), 4)
        mean_lon = round(float(group["longitude"].mean()), 4)

        corridors.append({
            "corridor_id": str(corridor_id),
            "project_type": str(group["project_type"].iloc[0]),
            "total_parcels": total_parcels,
            "high_risk_parcels": high_risk_count,
            "high_risk_pct": round(high_risk_count / total_parcels * 100, 1),
            "avg_delay_days": avg_delay,
            "avg_lapse_risk_pct": avg_lapse,
            "centroid": {"lat": mean_lat, "lon": mean_lon},
            "states_covered": sorted(group["state"].unique().tolist()),
            "districts_covered": sorted(group["district"].unique().tolist()),
        })

    corridors.sort(key=lambda x: x["high_risk_parcels"], reverse=True)
    return corridors


def get_gis_parcels(limit: Any = 500, state: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return geo-referenced parcels for Leaflet mapping."""
    if _cases_df is None:
        load_cases()

    assert _cases_df is not None
    df = _cases_df
    if state:
        df = df[df["state"].str.lower() == state.lower()]

    lim = int(getattr(limit, "default", limit))
    subset = df.head(lim)
    cols = [
        "case_id",
        "state",
        "district",
        "corridor_id",
        "latitude",
        "longitude",
        "project_type",
        "acquisition_stage",
        "predicted_additional_delay_days",
        "p10_delay_days",
        "p90_delay_days",
        "statutory_lapse_risk_pct",
        "risk_level",
    ]
    return subset[cols].to_dict(orient="records")


def get_alerts(limit: int = 50) -> List[Dict[str, Any]]:
    """Return high-risk cases sorted by predicted delay and lapse risk."""
    if _cases_df is None:
        load_cases()

    assert _cases_df is not None
    df = _cases_df[
        _cases_df["risk_level"] == "HIGH"
    ].sort_values(
        by=["statutory_lapse_risk_pct", "predicted_additional_delay_days"],
        ascending=[False, False],
    )

    columns = [
        "case_id",
        "state",
        "district",
        "corridor_id",
        "land_type",
        "project_type",
        "acquisition_stage",
        "litigation_present",
        "litigation_type",
        "objection_category",
        "predicted_additional_delay_days",
        "statutory_lapse_risk_pct",
        "risk_level",
    ]
    return df.head(limit)[columns].to_dict(orient="records")


def get_stats() -> Dict[str, Any]:
    """Return comprehensive executive dashboard statistics."""
    if _cases_df is None:
        load_cases()

    assert _cases_df is not None
    df = _cases_df

    risk_counts = df["risk_level"].value_counts().to_dict()
    high_lapse_count = int((df["statutory_lapse_risk_pct"] >= 50.0).sum())

    by_state = (
        df.groupby("state")["risk_level"]
        .apply(lambda s: (s == "HIGH").mean() * 100)
        .round(1)
        .sort_values(ascending=False)
        .to_dict()
    )

    litigation_stats = (
        df.groupby("litigation_present")["predicted_additional_delay_days"]
        .mean()
        .round(1)
        .to_dict()
    )

    return {
        "total_cases": int(len(df)),
        "risk_distribution": risk_counts,
        "high_risk_pct_by_state": by_state,
        "avg_predicted_delay_days": round(float(df["predicted_additional_delay_days"].mean()), 1),
        "statutory_lapse_critical_cases": high_lapse_count,
        "avg_statutory_lapse_risk_pct": round(float(df["statutory_lapse_risk_pct"].mean()), 1),
        "avg_predicted_delay_by_litigation": {
            "No": litigation_stats.get(0, 0),
            "Yes": litigation_stats.get(1, 0),
        },
    }
