# pyright: basic
"""
NexTerra AI API (SIH 26017)
Land Acquisition Delay Prediction, Statutory Lapse Risk, and Decision Support Engine
"""

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator

from src.model_service import (
    get_alerts,
    get_case_by_id,
    get_cases,
    get_corridor_summary,
    get_gis_parcels,
    get_model_info,
    get_stats,
    load_cases,
    MODEL_PATH,
    predict_case,
    simulate_counterfactual,
    STAGE_REFERENCE_DAYS,
)

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT.parent / "frontend"

app = FastAPI(
    title="NexTerra Land Acquisition Intelligence API",
    description="Domain-aware predictive analytics and statutory decision support under RFCTLARR Act 2013 — SIH 26017",
    version="2.1",
)

allowed_origins = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", "*").split(",")
    if origin.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins if allowed_origins != ["*"] else ["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup_event():
    """Ensure pre-trained model artifact and cached cases are loaded on server boot."""
    if MODEL_PATH.is_file():
        try:
            load_cases()
            print("NexTerra predictive models and bulk dataset successfully loaded on startup.")
        except Exception as exc:
            print(f"Warning: Startup preload encountered an error: {exc}")


class LandAcquisitionCase(BaseModel):
    """
    Case schema for land acquisition assessment.
    Auto-derives redundant fields (litigation_present, objection_present, stage_median_days_reference)
    to eliminate client-side API fragility and 422 rejections.
    """

    state: str = Field(min_length=2, max_length=80)
    district: str = Field(min_length=2, max_length=100)
    land_type: str = Field(min_length=2, max_length=40)
    project_type: str = Field(min_length=2, max_length=60)
    acquisition_stage: str = Field(min_length=2, max_length=80)

    # Progression and complexity metrics
    days_in_stage: int = Field(default=30, ge=0, le=5000)
    number_of_landowners: int = Field(default=15, ge=1, le=1000000)
    land_area_hectares: float = Field(default=5.0, gt=0, le=100000000)
    case_age_days: Optional[int] = Field(default=None, ge=0, le=10000)

    # Legal & objections
    litigation_type: str = Field(default="No Litigation", min_length=2, max_length=80)
    objection_category: str = Field(default="No Objection", min_length=2, max_length=100)
    number_of_objections: Optional[int] = Field(default=0, ge=0, le=1000000)

    # Compensation & documentation
    compensation_disputed: Optional[int] = Field(default=0, ge=0, le=1)
    compensation_delay_days: Optional[int] = Field(default=0, ge=0, le=10000)
    documentation_completeness_pct: float = Field(default=80.0, ge=0, le=100)
    previous_stage_delay_days: Optional[int] = Field(default=0, ge=0, le=10000)
    historical_delay_rate: Optional[float] = Field(default=0.12, ge=0, le=1)

    # GIS attributes (SIH 26017 requirement)
    corridor_id: Optional[str] = Field(default="CORRIDOR-GEN", max_length=80)
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)
    district_lgd_code: Optional[int] = Field(default=None)

    # Auto-derived redundant fields (optional so clients don't get 422 errors)
    stage_median_days_reference: Optional[int] = None
    litigation_present: Optional[int] = None
    objection_present: Optional[int] = None

    @model_validator(mode="after")
    def derive_and_reconcile_redundant_fields(self):
        """Auto-derive redundant fields internally without rejecting valid calls."""
        # 1. Derive stage median reference
        if self.stage_median_days_reference is None:
            self.stage_median_days_reference = STAGE_REFERENCE_DAYS.get(self.acquisition_stage, 45)

        # 2. Derive litigation_present
        if self.litigation_present is None:
            self.litigation_present = 0 if self.litigation_type == "No Litigation" else 1

        # 3. Derive objection_present and count
        if self.number_of_objections is None:
            self.number_of_objections = 0

        if self.objection_category == "No Objection":
            self.objection_present = 0
            self.number_of_objections = 0
        else:
            self.objection_present = 1
            if self.number_of_objections < 1:
                self.number_of_objections = 1

        # 4. Default previous delays and compensation disputes
        if self.compensation_disputed is None:
            self.compensation_disputed = 0
        if self.compensation_delay_days is None:
            self.compensation_delay_days = 0
        if self.previous_stage_delay_days is None:
            self.previous_stage_delay_days = 0

        return self


class SimulationPayload(BaseModel):
    """Payload for 'What-If' Counterfactual Simulation."""

    case_id: Optional[str] = None
    case_data: Optional[Dict[str, Any]] = None
    modifications: Optional[Dict[str, Any]] = None

    # Shortcut modification fields
    days_in_stage: Optional[int] = None
    resolve_litigation: Optional[bool] = None
    resolve_compensation_dispute: Optional[bool] = None
    resolve_objections: Optional[bool] = None
    fast_track_survey: Optional[bool] = None
    documentation_completeness_pct: Optional[float] = None


@app.get("/")
def root():
    if (FRONTEND / "index.html").is_file():
        return FileResponse(FRONTEND / "index.html")

    return {
        "service": "NexTerra Land Acquisition Intelligence API",
        "version": "2.1",
        "docs": "/docs",
    }


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "service": "NexTerra Land Acquisition Intelligence API",
        "model_available": MODEL_PATH.is_file(),
        "architecture": "Multi-Head HistGradientBoosting (Quantiles + RFCTLARR Sec 25 Lapse)",
    }


@app.get("/api/model-info")
def model_info():
    return get_model_info()


@app.post("/predict")
@app.post("/api/predict")
def predict(case: LandAcquisitionCase):
    """
    Run multi-head prediction:
    - Expected delay days (P50) and 80% confidence interval [P10, P90]
    - Calibrated Section 25 Statutory Lapse Risk under RFCTLARR Act 2013
    - Bidirectional SHAP (Accelerators vs Protective Mitigators)
    """
    try:
        return predict_case(case.model_dump())
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail="Prediction model artifact is not installed.",
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/simulate")
@app.post("/api/simulate")
def simulate(payload: SimulationPayload):
    """
    Interactive 'What-If' Counterfactual Simulation.
    Adjust parameters (e.g. resolve litigation, fast-track survey, complete documentation)
    and compute net days saved and reduction in Section 25 statutory lapse risk.
    """
    try:
        base_data: Optional[Dict[str, Any]] = None
        if payload.case_id:
            fetched = get_case_by_id(payload.case_id)
            if fetched is None:
                raise HTTPException(status_code=404, detail=f"Case '{payload.case_id}' not found")
            base_data = fetched
        elif payload.case_data:
            base_data = payload.case_data
        else:
            raise HTTPException(
                status_code=400,
                detail="Must provide either 'case_id' or 'case_data' for simulation.",
            )

        mods = payload.modifications or {}
        if payload.days_in_stage is not None:
            mods["days_in_stage"] = payload.days_in_stage
        if payload.resolve_litigation is not None:
            mods["resolve_litigation"] = payload.resolve_litigation
        if payload.resolve_compensation_dispute is not None:
            mods["resolve_compensation_dispute"] = payload.resolve_compensation_dispute
        if payload.resolve_objections is not None:
            mods["resolve_objections"] = payload.resolve_objections
        if payload.fast_track_survey is not None:
            mods["fast_track_survey"] = payload.fast_track_survey
        if payload.documentation_completeness_pct is not None:
            mods["documentation_completeness_pct"] = payload.documentation_completeness_pct

        return simulate_counterfactual(base_data, mods)

    except HTTPException:
        raise
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail="Prediction model artifact is not installed.",
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/api/corridors")
def corridors():
    """Return project corridor roll-up for SIH 26017 linear alignment visualization."""
    try:
        return {"corridors": get_corridor_summary()}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Model artifact or data not installed.") from exc


@app.get("/api/gis/parcels")
def gis_parcels(
    limit: int = Query(500, ge=1, le=2000),
    state: Optional[str] = None,
):
    """Return geo-referenced parcels for Leaflet corridor heatmap visualization."""
    try:
        return {"parcels": get_gis_parcels(limit=limit, state=state)}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Model artifact or data not installed.") from exc


@app.get("/cases")
def list_cases(
    state: Optional[str] = None,
    land_type: Optional[str] = None,
    acquisition_stage: Optional[str] = None,
    risk_level: Optional[str] = Query(None, description="LOW, MEDIUM, or HIGH"),
    corridor_id: Optional[str] = None,
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
):
    try:
        return get_cases(
            state=state,
            land_type=land_type,
            acquisition_stage=acquisition_stage,
            risk_level=risk_level,
            corridor_id=corridor_id,
            limit=limit,
            offset=offset,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed.") from exc


@app.get("/cases/{case_id}")
def get_case(case_id: str):
    try:
        result = get_case_by_id(case_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed.") from exc

    if result is None:
        raise HTTPException(status_code=404, detail=f"Case '{case_id}' not found")

    return result


@app.get("/alerts")
def alerts(limit: int = Query(50, ge=1, le=500)):
    try:
        return {"alerts": get_alerts(limit=limit)}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed.") from exc


@app.get("/stats")
def stats():
    try:
        return get_stats()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed.") from exc


if FRONTEND.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
