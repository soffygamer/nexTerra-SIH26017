# pyright: basic
"""
NexTerra End-to-End System Test Suite (SIH 26017)
Verifies:
1. RFCTLARR Act 2013 Domain and Legal Invariants
2. Model Artifact Integrity and Quantile Ordering (P10 <= P50 <= P90)
3. Calibrated Section 25 Statutory Lapse Risk
4. Bidirectional SHAP Explanations (Accelerators & Mitigators)
5. 'What-If' Counterfactual Simulator
6. Geospatial GIS Corridors & Parcels
7. API Resiliency & Auto-Derivation (No 422 Crashes on Missing Derived Fields)
"""

from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd
from api.main import (
    health,
    model_info,
    corridors,
    gis_parcels,
    predict,
    simulate,
    list_cases,
    alerts,
    stats,
    LandAcquisitionCase,
    SimulationPayload,
)
from src.model_service import (
    load_cases,
    get_case_by_id,
    MODEL_PATH,
    DATA_PATH,
    simulate_counterfactual,
)


class TestNexTerraSystem(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.df = pd.read_csv(DATA_PATH)
        load_cases()

    def test_01_model_artifact_exists(self):
        """Model artifact must exist and be tracked in the repository."""
        self.assertTrue(MODEL_PATH.is_file(), f"Missing model artifact at {MODEL_PATH}")
        size_mb = MODEL_PATH.stat().st_size / (1024 * 1024)
        self.assertLess(size_mb, 10.0, f"Model artifact too large: {size_mb:.2f} MB")

    def test_02_rfctlarr_statutory_invariants(self):
        """Check all procedural and legal invariants from RFCTLARR Act 2013."""
        df = self.df

        # Invariant 1: Stage 1 has strictly 0 previous delays
        stg1 = df[df["acquisition_stage"] == "Preliminary Notification"]
        self.assertEqual(
            (stg1["previous_stage_delay_days"] > 0).sum(),
            0,
            "Stage 1 cases cannot have previous stage delays!",
        )

        # Invariant 2: Stages 1-4 cannot have compensation disputes
        early_stages = [
            "Preliminary Notification",
            "Social Impact Assessment",
            "Declaration & Survey",
            "Expert Group Review",
        ]
        early_df = df[df["acquisition_stage"].isin(early_stages)]
        self.assertEqual(
            (early_df["compensation_disputed"] > 0).sum(),
            0,
            "Stages 1-4 cannot have compensation disputes!",
        )
        self.assertEqual(
            (early_df["compensation_delay_days"] > 0).sum(),
            0,
            "Stages 1-4 cannot have compensation delay days!",
        )

        # Invariant 3: Monotonically increasing case durations across stages
        mean_ages = df.groupby("acquisition_stage")["case_age_days"].mean()
        self.assertGreater(
            mean_ages["Possession"],
            mean_ages["Preliminary Notification"] * 4,
            "Possession duration must be substantially larger than Stage 1 duration",
        )

        # Invariant 4: No placeholder districts
        placeholder_count = df["district"].str.contains("District [0-9]", regex=True).sum()
        self.assertEqual(placeholder_count, 0, "Placeholder districts found in dataset!")

    def test_03_prediction_and_quantile_bounds(self):
        """Quantiles must satisfy P10 <= P50 <= P90."""
        case_data = {
            "state": "Maharashtra",
            "district": "Pune",
            "land_type": "Agricultural",
            "project_type": "Highway",
            "acquisition_stage": "Declaration & Survey",
            "days_in_stage": 45,
            "number_of_landowners": 25,
            "land_area_hectares": 12.0,
            "litigation_type": "No Litigation",
            "objection_category": "No Objection",
            "documentation_completeness_pct": 85.0,
        }
        req = LandAcquisitionCase(**case_data)
        res = predict(req)

        q = res["quantiles"]
        p10 = q["p10_best_case"]
        p50 = q["p50_expected"]
        p90 = q["p90_worst_case"]

        self.assertLessEqual(p10, p50)
        self.assertLessEqual(p50, p90)
        self.assertIn(res["risk_level"], ["LOW", "MEDIUM", "HIGH"])
        self.assertGreaterEqual(res["statutory_lapse_risk_pct"], 0.0)
        self.assertLessEqual(res["statutory_lapse_risk_pct"], 100.0)

    def test_04_bidirectional_shap(self):
        """SHAP explanations must return both Accelerators and Mitigators."""
        case_data = {
            "state": "Uttar Pradesh",
            "district": "Agra",
            "land_type": "Residential",
            "project_type": "Railway Line",
            "acquisition_stage": "Award (Compensation Determination)",
            "days_in_stage": 90,
            "number_of_landowners": 60,
            "land_area_hectares": 15.0,
            "litigation_type": "Compensation / Valuation",
            "compensation_disputed": 1,
            "compensation_delay_days": 35,
            "documentation_completeness_pct": 98.0,
        }
        res = predict(LandAcquisitionCase(**case_data))

        self.assertIn("risk_accelerators", res)
        self.assertIn("protective_mitigators", res)
        self.assertGreater(len(res["risk_accelerators"]), 0)
        # 98% documentation completeness should act as a mitigator
        self.assertGreater(len(res["protective_mitigators"]), 0)

        # Accelerators must have positive impact
        for a in res["risk_accelerators"]:
            self.assertGreater(a["impact_days"], 0)

        # Mitigators must have negative impact
        for m in res["protective_mitigators"]:
            self.assertLess(m["impact_days"], 0)

    def test_05_counterfactual_simulator(self):
        """Simulator must calculate net days saved and statutory lapse reduction."""
        case_data = {
            "state": "Rajasthan",
            "district": "Jaipur",
            "land_type": "Industrial",
            "project_type": "Industrial Corridor",
            "acquisition_stage": "Award (Compensation Determination)",
            "days_in_stage": 75,
            "number_of_landowners": 35,
            "land_area_hectares": 20.0,
            "litigation_type": "Land Ownership / Title",
            "compensation_disputed": 1,
            "compensation_delay_days": 40,
            "documentation_completeness_pct": 70.0,
        }
        payload = SimulationPayload(
            case_data=case_data,
            fast_track_survey=True,
            resolve_litigation=True,
            resolve_compensation_dispute=True,
            documentation_completeness_pct=100.0,
        )
        sim = simulate(payload)

        summary = sim["impact_summary"]
        self.assertGreater(summary["net_days_saved"], 0, "Interventions should save days!")
        self.assertGreater(summary["pct_delay_reduction"], 0.0)
        self.assertGreaterEqual(summary["statutory_lapse_risk_reduction_pct"], 0.0)
        self.assertIn("recommendation", sim)

    def test_06_corridors_and_gis(self):
        """Corridors and GIS parcels endpoints must return valid data."""
        corr = corridors()
        self.assertIn("corridors", corr)
        self.assertGreater(len(corr["corridors"]), 0)

        parc = gis_parcels(limit=50)
        self.assertIn("parcels", parc)
        self.assertEqual(len(parc["parcels"]), 50)
        p0 = parc["parcels"][0]
        self.assertIn("latitude", p0)
        self.assertIn("longitude", p0)
        self.assertIn("corridor_id", p0)

    def test_07_api_resilience(self):
        """API must gracefully auto-derive redundant fields without 422 error."""
        minimal_case = {
            "state": "Gujarat",
            "district": "Ahmedabad",
            "land_type": "Commercial",
            "project_type": "Highway",
            "acquisition_stage": "Possession",
        }
        # Should not raise validation error even without litigation_present, objection_present, etc.
        case_obj = LandAcquisitionCase(**minimal_case)
        self.assertEqual(case_obj.litigation_present, 0)
        self.assertEqual(case_obj.objection_present, 0)
        self.assertEqual(case_obj.stage_median_days_reference, 45)

        res = predict(case_obj)
        self.assertIn("predicted_additional_delay_days", res)


if __name__ == "__main__":
    unittest.main()
