# SIH 26017 deck — recommended edits

The reviewer’s main ask is to connect the prediction to a real decision: what an official does next, how that changes current handling, and who benefits. Keep the deck focused on that path.

## Slide-by-slide edits

### 1. Cover — identify the exact challenge and team

- Correct the title to **Predictive Analytics System for Early Detection of Land Acquisition Delays**.
- Keep **SIH26017** prominent; fill in the missing team ID and team name fields.
- Use the same capitalization and problem title wherever it appears.

### 2. Solution — state the operational value

Replace the repeated product title with:

> **NexTerra: early warning and case triage for land acquisition**  
> Estimates remaining delay, explains the main case drivers, and routes a review to the responsible district team.

Label the current implementation as a **prototype**. Avoid implying a government integration or a live data feed that the package does not contain.

### 3. Technical approach — match the code and show the decision loop

Use a simple left-to-right flow:

> Case snapshot → input checks → delay estimate and risk tier → SHAP drivers → officer review → assigned follow-up → actual outcome recorded

Name only fields present in the prototype: state, district, land type, acquisition stage, case age, days in stage, landowners, litigation, objections, compensation delay, earlier-stage delay, historical delay rate, and land area.

The supplied build uses **Python, FastAPI, scikit-learn Random Forest, SHAP, and a browser-based frontend**. Remove Next.js and PostgreSQL from the “built” stack unless the team adds them. Mark government data ingestion and live alerts as planned work if they are not implemented. Fix “fikes,” “show”/“shows,” and “lay delay factors.”

### 4. Feasibility — replace unsupported data and accuracy claims

The slide says “6,000 case synthetic dataset calibrated to official govt. statistics & parliament disclosures.” The project package instead contains an 8,000-row CSV with placeholder districts such as “Bihar District 1.” The deck shows public aggregate figures, but the package does not document how those aggregates generated or calibrated individual rows. Replace that sentence with:

> **Prototype data:** 8,000 demonstration rows; placeholder districts are present. We will not claim field accuracy until the data source and labels are verified and the model is tested on documented cases.

Show the real feasibility dependency: access to dated case snapshots and eventual outcomes. Explain how the team will prevent leakage by using only fields known at each snapshot. Present the four-week timeline as a **pilot plan** with data access and validation gates, rather than evidence that official integration is already available.

### 5. Impact and benefits — show who acts and how success is measured

Replace “Reduced Delays” and “improved citizen trust” as achieved outcomes with testable goals. Name users and beneficiaries directly:

- **Primary users:** Special Land Acquisition Officers, district case officers, and the District Collector’s coordination team.
- **Decision supported:** which case should receive review first, what is driving its risk, and which office should own the next check.
- **Beneficiaries:** project departments through better visibility; affected landowners through clearer follow-up and fewer missed hand-offs. Treat these as intended benefits to measure, not proven results.
- **Pilot measures:** MAE in days against a median baseline; precision and recall for the high-risk tier at department-approved thresholds; time from risk flag to assigned action; and actual stage time after intervention.

Suggested workflow caption:

> **Flag → verify the record → assign the responsible office → record the action → compare forecast with actual outcome**

Correct “Authorizes take timely action” to **“The case officer assigns a follow-up and records the outcome.”** State that the model supports prioritization; an officer verifies the record and chooses the intervention.

### 6. Research and references — make the evidence traceable

This slide includes image cards for the RFCTLARR Act, public data points, and delay statistics, but source names and dates are hard to read and several claims point to secondary sources. Keep the useful references, then add an editable source list with title, issuing organization, publication date, direct URL, and the exact claim each source supports. Prefer the original government record for project counts and acquisition figures. Add the SIH problem statement, the demo-data generation method, and model-evaluation method. Distinguish **official facts**, **team assumptions**, and **prototype results**. Verify every number and reporting date; remove any claim the team cannot trace.

## Demo changes made to match the feedback

The updated demo makes the officer workflow visible, names likely owners for suggested reviews, explains who benefits, and adds a validation panel. Retraining records held-out-state MAE, RMSE, R² and median-baseline MAE. The packaged model does not have a verifiable report yet; the panel says so rather than inventing an accuracy claim. These metrics will still describe demo data until the team validates on documented case records.
