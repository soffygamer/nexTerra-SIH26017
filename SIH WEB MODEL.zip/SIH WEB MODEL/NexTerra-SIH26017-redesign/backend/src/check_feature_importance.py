from pathlib import Path

import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

MODEL_PATH = ROOT / "models" / "nexterra_delay_model.pkl"

pipeline = joblib.load(MODEL_PATH)

preprocessor = pipeline.named_steps["preprocessor"]
model = pipeline.named_steps["model"]

# Get feature names after preprocessing
feature_names = preprocessor.get_feature_names_out()

# Random Forest feature importance
importance = model.feature_importances_

importance_df = pd.DataFrame({
    "feature": feature_names,
    "importance": importance
})

importance_df = importance_df.sort_values(
    by="importance",
    ascending=False
)

print("\n===== GLOBAL FEATURE IMPORTANCE =====\n")

for _, row in importance_df.head(20).iterrows():
    print(
        f"{row['feature']:<65} "
        f"{row['importance']:.4f}"
    )
