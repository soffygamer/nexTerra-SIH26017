# pyright: basic
from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
import shap

BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_PATH = BASE_DIR / "models" / "nexterra_delay_model.pkl"
MODEL_REPORT_PATH = BASE_DIR / "models" / "model_validation.json"
DATA_PATH = BASE_DIR / "data" / "nexterra_land_acquisition_8000_redesigned_v2.csv"

pipeline = None
preprocessor = None
model = None
explainer = None


def _load_model():
    """Load the trained pipeline and SHAP explainer lazily."""
    global pipeline, preprocessor, model, explainer

    if pipeline is None:
        if not MODEL_PATH.is_file():
            raise FileNotFoundError(MODEL_PATH)

        pipeline = joblib.load(MODEL_PATH)
        preprocessor = pipeline.named_steps["preprocessor"]
        model = pipeline.named_steps["model"]
        explainer = shap.TreeExplainer(model)

    return pipeline, preprocessor, explainer


def risk_from_delay(predicted_delay):
    # Prototype thresholds for the redesigned target distribution.
    # They are presentation rules, not a clinical/legal/administrative standard.
    if predicted_delay < 60:
        return "LOW"
    elif predicted_delay < 120:
        return "MEDIUM"
    return "HIGH"


def get_model_info():
    """Return validation metadata without implying real-world accuracy."""
    default = {
        "model_available": MODEL_PATH.is_file(),
        "validation_status": "not_available",
        "data_status": "synthetic_demo_data",
        "metrics": None,
        "message": (
            "The model is trained on synthetic demonstration data. "
            "Validate on documented historical administrative cases before operational use."
        ),
    }

    if not MODEL_REPORT_PATH.is_file():
        return default

    try:
        report = json.loads(
            MODEL_REPORT_PATH.read_text(encoding="utf-8")
        )
    except (OSError, json.JSONDecodeError):
        return default

    return {
        **default,
        "validation_status": "state_group_holdout_on_synthetic_data",
        "metrics": report,
        "message": (
            "These metrics are from a held-out-state split of synthetic demo data "
            "and do not establish accuracy on real administrative records."
        ),
    }


feature_info = {
    "numeric__stage_median_days_reference": (
        "Stage reference duration",
        "The expected reference duration of the current acquisition stage helps the model identify unusually slow stages.",
    ),
    "numeric__case_age_days": (
        "Case age",
        "Older cases may indicate that the acquisition process has already encountered difficulties.",
    ),
    "numeric__days_in_stage": (
        "Days in current stage",
        "A case that has already spent significant time in its current stage may face further delay.",
    ),
    "numeric__number_of_landowners": (
        "Number of landowners",
        "More landowners can increase coordination, verification, and settlement complexity.",
    ),
    "numeric__land_area_hectares": (
        "Land area",
        "Larger acquisition areas can involve greater coordination and processing requirements.",
    ),
    "numeric__litigation_present": (
        "Litigation present",
        "Active litigation can introduce legal uncertainty and extend the acquisition timeline.",
    ),
    "numeric__objection_present": (
        "Objections present",
        "Formal objections can require additional review, communication, and resolution.",
    ),
    "numeric__number_of_objections": (
        "Number of objections",
        "More objections can increase the time required for review and resolution.",
    ),
    "numeric__compensation_disputed": (
        "Compensation disputed",
        "A compensation dispute can require additional valuation, review, or settlement work.",
    ),
    "numeric__compensation_delay_days": (
        "Compensation delay",
        "Existing compensation delays can indicate difficulty completing the acquisition process.",
    ),
    "numeric__documentation_completeness_pct": (
        "Documentation completeness",
        "Incomplete documentation can create administrative rework and slow case processing.",
    ),
    "numeric__previous_stage_delay_days": (
        "Previous stage delay",
        "Delays in earlier stages can indicate unresolved issues affecting the current case.",
    ),
    "numeric__historical_delay_rate": (
        "Historical delay rate",
        "A higher historical delay rate indicates that similar cases have frequently experienced delays.",
    ),
}


categorical_labels = {
    "state": "State",
    "district": "District",
    "land_type": "Land type",
    "project_type": "Project type",
    "acquisition_stage": "Acquisition stage",
    "litigation_type": "Litigation type",
    "objection_category": "Objection category",
}


def _format_value(feature, value):
    if feature == "numeric__litigation_present":
        return "Yes" if int(value) == 1 else "No"

    if feature == "numeric__objection_present":
        return "Yes" if int(value) == 1 else "No"

    if feature == "numeric__compensation_disputed":
        return "Yes" if int(value) == 1 else "No"

    if feature == "numeric__historical_delay_rate":
        return f"{float(value) * 100:.0f}%"

    if feature == "numeric__documentation_completeness_pct":
        return f"{float(value):.0f}%"

    return value.item() if hasattr(value, "item") else value


def _categorical_reason(label, value):
    if label == "Litigation type" and value != "None":
        return (
            f"The case has a {str(value).lower()} litigation pattern, "
            "which can add legal or administrative resolution time."
        )

    if label == "Objection category" and value != "None":
        return (
            f"The case contains a {str(value).lower()}, "
            "which may require additional review or resolution."
        )

    return (
        f"The model's learned historical pattern for this "
        f"{label.lower()} contributes to the prediction."
    )


def predict_case(case_data):
    pipeline, preprocessor, explainer = _load_model()

    case = pd.DataFrame([case_data])

    predicted_delay = round(float(pipeline.predict(case)[0]))
    predicted_delay = max(0, predicted_delay)
    risk = risk_from_delay(predicted_delay)

    transformed_case = preprocessor.transform(case)

    if hasattr(transformed_case, "toarray"):
        transformed_case = transformed_case.toarray()

    transformed_case = np.asarray(
        transformed_case,
        dtype=np.float64,
    )

    shap_values = np.asarray(
        explainer.shap_values(transformed_case)
    )

    if shap_values.ndim > 1:
        shap_values = shap_values[0]

    shap_values = shap_values.reshape(-1)

    feature_names = preprocessor.get_feature_names_out()

    if len(feature_names) != len(shap_values):
        raise ValueError(
            "SHAP output does not match the transformed feature count"
        )

    explanation = pd.DataFrame(
        {
            "feature": feature_names,
            "shap_value": shap_values,
        }
    )

    # Only show features that push this particular prediction upward.
    explanation = explanation[
        explanation["shap_value"] > 0
    ].sort_values(
        by="shap_value",
        ascending=False,
    )

    reasons = []

    for _, row in explanation.iterrows():
        feature = str(row["feature"])
        impact = float(row["shap_value"])

        if feature in feature_info:
            name, reason = feature_info[feature]
            raw_column = feature.replace("numeric__", "")
            value = _format_value(feature, case_data[raw_column])

            reasons.append(
                {
                    "feature": name,
                    "value": value,
                    "impact_days": round(impact, 2),
                    "reason": reason,
                }
            )
            continue

        if feature.startswith("categorical__"):
            encoded_name = feature.removeprefix("categorical__")

            column = next(
                (
                    candidate
                    for candidate in categorical_labels
                    if encoded_name.startswith(f"{candidate}_")
                ),
                None,
            )

            if column:
                category = encoded_name[len(column) + 1 :]

                if str(case_data[column]) == category:
                    label = categorical_labels[column]

                    reasons.append(
                        {
                            "feature": label,
                            "value": case_data[column],
                            "impact_days": round(impact, 2),
                            "reason": _categorical_reason(
                                label,
                                case_data[column],
                            ),
                        }
                    )

    reasons = reasons[:5]

    return {
        "predicted_additional_delay_days": predicted_delay,
        "risk_level": risk,
        "reasons": reasons,
    }


# ==========================================
# Bulk dataset + cached predictions
# ==========================================

_FEATURE_COLUMNS = [
    "state",
    "district",
    "land_type",
    "project_type",
    "acquisition_stage",
    "stage_median_days_reference",
    "case_age_days",
    "days_in_stage",
    "number_of_landowners",
    "land_area_hectares",
    "litigation_present",
    "litigation_type",
    "objection_present",
    "objection_category",
    "number_of_objections",
    "compensation_disputed",
    "compensation_delay_days",
    "documentation_completeness_pct",
    "previous_stage_delay_days",
    "historical_delay_rate",
]

_cases_df = None


def load_cases():
    """
    Load the redesigned dataset once, run vectorized predictions,
    and cache the result in memory.
    """
    global _cases_df

    pipeline, _, _ = _load_model()

    if not DATA_PATH.is_file():
        raise FileNotFoundError(DATA_PATH)

    df = pd.read_csv(DATA_PATH)

    missing = [
        col for col in _FEATURE_COLUMNS
        if col not in df.columns
    ]

    if missing:
        raise ValueError(
            f"Dataset is missing required columns: {missing}"
        )

    predictions = pipeline.predict(
        df[_FEATURE_COLUMNS]
    )

    df["predicted_additional_delay_days"] = (
        predictions.round(0).astype(int)
    )

    df["risk_level"] = (
        df["predicted_additional_delay_days"]
        .apply(risk_from_delay)
    )

    _cases_df = df
    return _cases_df


def get_cases(
    state=None,
    land_type=None,
    acquisition_stage=None,
    risk_level=None,
    limit=50,
    offset=0,
):
    """Return filtered, paginated cases with cached predictions."""
    if _cases_df is None:
        load_cases()

    df = _cases_df

    if state:
        df = df[
            df["state"].str.lower() == state.lower()
        ]

    if land_type:
        df = df[
            df["land_type"].str.lower() == land_type.lower()
        ]

    if acquisition_stage:
        df = df[
            df["acquisition_stage"].str.lower()
            == acquisition_stage.lower()
        ]

    if risk_level:
        df = df[
            df["risk_level"].str.upper()
            == risk_level.upper()
        ]

    total = len(df)
    page = df.iloc[offset:offset + limit]

    columns = [
        "case_id",
        "state",
        "district",
        "land_type",
        "project_type",
        "acquisition_stage",
        "days_in_stage",
        "litigation_present",
        "litigation_type",
        "objection_category",
        "predicted_additional_delay_days",
        "risk_level",
    ]

    return {
        "total": int(total),
        "limit": limit,
        "offset": offset,
        "cases": page[columns].to_dict(
            orient="records"
        ),
    }


def get_case_by_id(case_id):
    """Return one dataset case with its prediction and SHAP reasons."""
    if _cases_df is None:
        load_cases()

    match = _cases_df[
        _cases_df["case_id"] == case_id
    ]

    if match.empty:
        return None

    row = match.iloc[0]

    case_data = {
        col: (
            row[col].item()
            if hasattr(row[col], "item")
            else row[col]
        )
        for col in _FEATURE_COLUMNS
    }

    result = predict_case(case_data)

    result["case_id"] = str(case_id)
    result["state"] = str(row["state"])
    result["district"] = str(row["district"])
    result["project_type"] = str(row["project_type"])
    result["acquisition_stage"] = str(
        row["acquisition_stage"]
    )

    return result


def get_alerts(limit=50):
    """Return HIGH-risk cases, sorted by predicted delay."""
    if _cases_df is None:
        load_cases()

    df = _cases_df[
        _cases_df["risk_level"] == "HIGH"
    ].sort_values(
        by="predicted_additional_delay_days",
        ascending=False,
    )

    columns = [
        "case_id",
        "state",
        "district",
        "land_type",
        "project_type",
        "acquisition_stage",
        "litigation_present",
        "litigation_type",
        "objection_category",
        "predicted_additional_delay_days",
        "risk_level",
    ]

    return df.head(limit)[columns].to_dict(
        orient="records"
    )


def get_stats():
    """Return dashboard summary statistics."""
    if _cases_df is None:
        load_cases()

    df = _cases_df

    risk_counts = (
        df["risk_level"]
        .value_counts()
        .to_dict()
    )

    by_state = (
        df.groupby("state")["risk_level"]
        .apply(lambda s: (s == "HIGH").mean() * 100)
        .round(1)
        .sort_values(ascending=False)
        .to_dict()
    )

    litigation_stats = (
        df.groupby("litigation_present")[
            "predicted_additional_delay_days"
        ]
        .mean()
        .round(1)
        .to_dict()
    )

    return {
        "total_cases": int(len(df)),
        "risk_distribution": risk_counts,
        "high_risk_pct_by_state": by_state,
        "avg_predicted_delay_days": round(
            float(
                df["predicted_additional_delay_days"]
                .mean()
            ),
            1,
        ),
        "avg_predicted_delay_by_litigation": {
            "No": litigation_stats.get(0, 0),
            "Yes": litigation_stats.get(1, 0),
        },
    }
