# pyright: basic
from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
import shap

# Load trained model
# Path is resolved relative to this file, not the current working directory,
# so the API works no matter where uvicorn is launched from.

BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_PATH = BASE_DIR / "models" / "nexterra_delay_model.pkl"
MODEL_REPORT_PATH = BASE_DIR / "models" / "model_validation.json"
DATA_PATH = BASE_DIR / "data" / "nexterra_land_acquisition_8000.csv"

pipeline = None
preprocessor = None
model = None
explainer = None


def _load_model():
    """Load model and explainer only when predictions are first requested."""
    global pipeline, preprocessor, model, explainer
    if pipeline is None:
        if not MODEL_PATH.is_file():
            raise FileNotFoundError(MODEL_PATH)
        pipeline = joblib.load(MODEL_PATH)
        preprocessor = pipeline.named_steps["preprocessor"]
        model = pipeline.named_steps["model"]
        explainer = shap.TreeExplainer(model)
    return pipeline, preprocessor, explainer


def risk_from_delay(predicted_delay):
    if predicted_delay < 120:
        return "LOW"
    elif predicted_delay < 200:
        return "MEDIUM"
    else:
        return "HIGH"


def get_model_info():
    """Return validation metadata without presenting demo scores as field accuracy."""
    default = {
        "model_available": MODEL_PATH.is_file(),
        "validation_status": "not_available",
        "data_status": "demo_data_unverified",
        "metrics": None,
        "message": "The packaged model has no validation report. Validate on documented historical cases before operational use.",
    }
    if not MODEL_REPORT_PATH.is_file():
        return default
    try:
        report = json.loads(MODEL_REPORT_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default
    return {
        **default,
        "validation_status": "demo_holdout_evaluation",
        "metrics": report,
        "message": "These are held-out-state results on bundled demo data; they do not establish accuracy on administrative case records.",
    }

# Feature explanations

feature_info = {
    "numeric__number_of_landowners": (
        "Number of landowners",
        "A large number of landowners can increase coordination and settlement complexity.",
    ),
    "numeric__days_in_stage": (
        "Days in current stage",
        "A case that has already spent significant time in its current stage may face further delay.",
    ),
    "numeric__compensation_delay_days": (
        "Compensation delay",
        "Existing compensation delays can indicate difficulty completing the acquisition process.",
    ),
    "numeric__historical_delay_rate": (
        "Historical delay rate",
        "A higher historical delay rate indicates that similar cases have frequently experienced delays.",
    ),
    "numeric__litigation_present": (
        "Litigation present",
        "Litigation can introduce legal uncertainty and extend the acquisition timeline.",
    ),
    "numeric__number_of_objections": (
        "Number of objections",
        "More objections can increase the time required for review and resolution.",
    ),
    "numeric__previous_stage_delay_days": (
        "Previous stage delay",
        "Delays in earlier stages can indicate unresolved issues affecting the current case.",
    ),
    "numeric__land_area_hectares": (
        "Land area",
        "Larger acquisition areas can involve greater coordination and processing requirements.",
    ),
    "numeric__case_age_days": (
        "Case age",
        "Older cases may indicate that the acquisition process has already encountered difficulties.",
    ),
}

# Prediction function


def predict_case(case_data):

    pipeline, preprocessor, explainer = _load_model()

    # Convert incoming data to DataFrame
    case = pd.DataFrame([case_data])

    # Predict delay

    predicted_delay = pipeline.predict(case)[0]

    predicted_delay = round(float(predicted_delay))

    # Risk level

    risk = risk_from_delay(predicted_delay)

    # Transform case for SHAP

    transformed_case = preprocessor.transform(case)

    if hasattr(transformed_case, "toarray"):
        transformed_case = transformed_case.toarray()

    transformed_case = np.asarray(transformed_case, dtype=np.float64)

    # Calculate SHAP values

    shap_values = explainer.shap_values(transformed_case)

    shap_values = np.asarray(shap_values)

    if shap_values.ndim > 1:
        shap_values = shap_values[0]
    shap_values = shap_values.reshape(-1)

    # Feature names
    feature_names = preprocessor.get_feature_names_out()
    if len(feature_names) != len(shap_values):
        raise ValueError("SHAP output does not match the transformed feature count")

    # Build explanation

    explanation = pd.DataFrame({"feature": feature_names, "shap_value": shap_values})

    # Only factors increasing delay
    explanation = explanation[explanation["shap_value"] > 0]

    explanation = explanation.sort_values(by="shap_value", ascending=False)

    # Convert to clean reasons

    reasons = []

    for _, row in explanation.iterrows():
        feature = str(row["feature"])
        impact = float(row["shap_value"])

        # Normal numeric feature
        if feature in feature_info:
            name, reason = feature_info[feature]

            value = case_data[feature.replace("numeric__", "")]

            if feature == "numeric__litigation_present":
                value = "Yes" if value == 1 else "No"

            elif feature == "numeric__historical_delay_rate":
                value = f"{value * 100:.0f}%"

            reasons.append(
                {
                    "feature": name,
                    "value": value,
                    "impact_days": round(impact, 2),
                    "reason": reason,
                }
            )

        # One-hot feature names are categorical__<column>_<category>.
        elif feature.startswith("categorical__"):
            encoded_name = feature.removeprefix("categorical__")
            column = next(
                (candidate for candidate in ("acquisition_stage", "land_type", "district", "state")
                 if encoded_name.startswith(f"{candidate}_")),
                None,
            )
            if column and case_data[column] == encoded_name[len(column) + 1 :]:
                label = {"state": "State", "district": "District", "land_type": "Land type",
                         "acquisition_stage": "Acquisition stage"}[column]
                reasons.append({
                    "feature": label,
                    "value": case_data[column],
                    "impact_days": round(impact, 2),
                    "reason": f"The model's learned historical pattern for this {label.lower()} contributes to the prediction.",
                })

    # Keep top 5 reasons
    reasons = reasons[:5]

    # Return result

    return {
        "predicted_additional_delay_days": predicted_delay,
        "risk_level": risk,
        "reasons": reasons,
    }


# ==========================================
# Bulk dataset + cached predictions
# (used by the /cases, /cases/{id}, /alerts, /stats endpoints)
# ==========================================

_FEATURE_COLUMNS = [
    "state",
    "district",
    "land_type",
    "acquisition_stage",
    "case_age_days",
    "days_in_stage",
    "number_of_landowners",
    "litigation_present",
    "number_of_objections",
    "compensation_delay_days",
    "previous_stage_delay_days",
    "historical_delay_rate",
    "land_area_hectares",
]

_cases_df = None  # populated once by load_cases()


def load_cases():
    """
    Loads the case dataset once, runs a single vectorized bulk prediction
    over all rows (fast — no per-row SHAP), and caches the result in memory.
    Called once at API startup.
    """
    global _cases_df

    pipeline, _, _ = _load_model()
    df = pd.read_csv(DATA_PATH)

    predictions = pipeline.predict(df[_FEATURE_COLUMNS])
    df["predicted_additional_delay_days"] = predictions.round(0).astype(int)
    df["risk_level"] = df["predicted_additional_delay_days"].apply(risk_from_delay)

    _cases_df = df
    return _cases_df


def get_cases(state=None, land_type=None, acquisition_stage=None, risk_level=None,
              limit=50, offset=0):
    """Filtered, paginated list of cases with their cached predictions."""
    if _cases_df is None:
        load_cases()

    df = _cases_df

    if state:
        df = df[df["state"].str.lower() == state.lower()]
    if land_type:
        df = df[df["land_type"].str.lower() == land_type.lower()]
    if acquisition_stage:
        df = df[df["acquisition_stage"].str.lower() == acquisition_stage.lower()]
    if risk_level:
        df = df[df["risk_level"].str.upper() == risk_level.upper()]

    total = len(df)
    page = df.iloc[offset: offset + limit]

    columns = ["case_id", "state", "district", "land_type", "acquisition_stage",
               "days_in_stage", "predicted_additional_delay_days", "risk_level"]

    return {
        "total": int(total),
        "limit": limit,
        "offset": offset,
        "cases": page[columns].to_dict(orient="records"),
    }


def get_case_by_id(case_id):
    """Full prediction (incl. SHAP reasons) for one case, looked up by case_id."""
    if _cases_df is None:
        load_cases()

    match = _cases_df[_cases_df["case_id"] == case_id]

    if match.empty:
        return None

    row = match.iloc[0]
    # Cast numpy scalar types (int64, float64) to plain Python types —
    # FastAPI's JSON encoder can't serialize numpy types directly.
    case_data = {col: row[col].item() if hasattr(row[col], "item") else row[col]
                 for col in _FEATURE_COLUMNS}

    result = predict_case(case_data)
    result["case_id"] = str(case_id)
    result["state"] = str(row["state"])
    result["district"] = str(row["district"])
    result["acquisition_stage"] = str(row["acquisition_stage"])

    return result


def get_alerts(limit=50):
    """Cases at HIGH risk, sorted by predicted delay, worst first."""
    if _cases_df is None:
        load_cases()

    df = _cases_df[_cases_df["risk_level"] == "HIGH"]
    df = df.sort_values(by="predicted_additional_delay_days", ascending=False)

    columns = ["case_id", "state", "district", "land_type", "acquisition_stage",
               "predicted_additional_delay_days", "risk_level"]

    return df.head(limit)[columns].to_dict(orient="records")


def get_stats():
    """Summary numbers for dashboard charts: risk-tier split and per-state split."""
    if _cases_df is None:
        load_cases()

    df = _cases_df

    risk_counts = df["risk_level"].value_counts().to_dict()

    by_state = (
        df.groupby("state")["risk_level"]
        .apply(lambda s: (s == "HIGH").mean() * 100)
        .round(1)
        .sort_values(ascending=False)
        .to_dict()
    )

    return {
        "total_cases": int(len(df)),
        "risk_distribution": risk_counts,
        "high_risk_pct_by_state": by_state,
        "avg_predicted_delay_days": round(
            float(df["predicted_additional_delay_days"].mean()), 1
        ),
    }
