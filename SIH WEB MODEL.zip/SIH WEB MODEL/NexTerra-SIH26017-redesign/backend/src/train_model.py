# pyright: basic
import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "nexterra_land_acquisition_8000_redesigned_v2.csv"

df = pd.read_csv(DATA_PATH)

TARGET = "final_additional_delay_days"

X = df.drop(columns=["case_id", TARGET])
y = df[TARGET]

categorical_features = [
    "state",
    "district",
    "land_type",
    "project_type",
    "acquisition_stage",
    "litigation_type",
    "objection_category",
]

numeric_features = [
    "stage_median_days_reference",
    "case_age_days",
    "days_in_stage",
    "number_of_landowners",
    "land_area_hectares",
    "litigation_present",
    "objection_present",
    "number_of_objections",
    "compensation_disputed",
    "compensation_delay_days",
    "documentation_completeness_pct",
    "previous_stage_delay_days",
    "historical_delay_rate",
]

preprocessor = ColumnTransformer(
    transformers=[
        (
            "categorical",
            OneHotEncoder(handle_unknown="ignore"),
            categorical_features,
        ),
        ("numeric", "passthrough", numeric_features),
    ]
)

model = RandomForestRegressor(
    n_estimators=400,
    min_samples_leaf=3,
    max_depth=24,
    max_features=0.8,
    random_state=42,
    n_jobs=-1,
)

pipeline = Pipeline(
    [
        ("preprocessor", preprocessor),
        ("model", model),
    ]
)

# Hold out complete states so the evaluation checks generalization
# to geographic regions that were not used for training.
splitter = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=42)
train_indices, test_indices = next(
    splitter.split(X, y, groups=X["state"])
)

X_train = X.iloc[train_indices]
X_test = X.iloc[test_indices]
y_train = y.iloc[train_indices]
y_test = y.iloc[test_indices]

print("\nTraining NexTerra model...")
print(f"Dataset: {DATA_PATH.name}")
print(f"Rows: {len(df)}")
print(f"Features: {len(X.columns)}")
print(f"Train rows: {len(X_train)}")
print(f"Test rows: {len(X_test)}")
print("Held-out states:", ", ".join(sorted(X_test["state"].unique())))

pipeline.fit(X_train, y_train)

print("Training complete!")

y_pred = pipeline.predict(X_test)

baseline = DummyRegressor(strategy="median")
baseline.fit(X_train, y_train)
baseline_pred = baseline.predict(X_test)

mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = mse ** 0.5
r2 = r2_score(y_test, y_pred)
baseline_mae = mean_absolute_error(y_test, baseline_pred)

print("\n===== MODEL PERFORMANCE =====")
print(f"MAE  : {mae:.2f} days")
print(f"RMSE : {rmse:.2f} days")
print(f"R²   : {r2:.4f}")
print(f"Baseline median MAE: {baseline_mae:.2f} days")

results = pd.DataFrame(
    {
        "Actual Delay": y_test.to_numpy(),
        "Predicted Delay": y_pred.round(0).astype(int),
    }
)

print("\n===== SAMPLE PREDICTIONS =====")
print(results.head(10).to_string(index=False))

model_dir = ROOT / "models"
model_dir.mkdir(parents=True, exist_ok=True)

report = {
    "evaluation_split": "state_group_holdout",
    "dataset_status": "synthetic_demo_data",
    "dataset_file": DATA_PATH.name,
    "total_rows": int(len(df)),
    "train_rows": int(len(X_train)),
    "test_rows": int(len(X_test)),
    "held_out_states": sorted(X_test["state"].unique().tolist()),
    "model": "RandomForestRegressor",
    "n_estimators": 400,
    "min_samples_leaf": 3,
    "max_depth": 24,
    "max_features": 0.8,
    "model_mae_days": round(float(mae), 3),
    "model_rmse_days": round(float(rmse), 3),
    "model_r2": round(float(r2), 4),
    "median_baseline_mae_days": round(float(baseline_mae), 3),
    "target": TARGET,
}

(model_dir / "model_validation.json").write_text(
    json.dumps(report, indent=2),
    encoding="utf-8",
)

joblib.dump(
    pipeline,
    model_dir / "nexterra_delay_model.pkl",
    compress=3,
)

print("\nModel saved successfully!")
print(f"Model: {model_dir / 'nexterra_delay_model.pkl'}")
print(f"Report: {model_dir / 'model_validation.json'}")
