# pyright: basic
import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "nexterra_land_acquisition_8000.csv")

X = df.drop(columns=["case_id", "final_additional_delay_days"])

y = df["final_additional_delay_days"]

categorical_features = ["state", "district", "land_type", "acquisition_stage"]

numeric_features = [
    "case_age_days",
    "days_in_stage",
    "number_of_landowners",
    "litigation_present",
    "number_of_objections",
    "compensation_delay_days",
    "previous_stage_delay_days",
    "historical_delay_rate",
    "land_area_hectares",
]

preprocessor = ColumnTransformer(
    transformers=[
        ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical_features),
        ("numeric", "passthrough", numeric_features),
    ]
)

model = RandomForestRegressor(
    n_estimators=200, min_samples_leaf=2, max_depth=24, random_state=42, n_jobs=-1
)

pipeline = Pipeline([("preprocessor", preprocessor), ("model", model)])

# Keep whole states out of the training fold to check generalization to unseen regions.
splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
train_indices, test_indices = next(splitter.split(X, y, groups=X["state"]))
X_train, X_test = X.iloc[train_indices], X.iloc[test_indices]
y_train, y_test = y.iloc[train_indices], y.iloc[test_indices]

print("\nTraining model...")

pipeline.fit(X_train, y_train)

print("Training complete!")

y_pred = pipeline.predict(X_test)
baseline = DummyRegressor(strategy="median").fit(X_train, y_train)
baseline_pred = baseline.predict(X_test)

mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = mse**0.5
r2 = r2_score(y_test, y_pred)

print("\n===== MODEL PERFORMANCE =====")

print(f"MAE  : {mae:.2f} days")
print(f"RMSE : {rmse:.2f} days")
print(f"R²   : {r2:.4f}")
print(f"Baseline median MAE: {mean_absolute_error(y_test, baseline_pred):.2f} days")
print("Held-out states:", ", ".join(sorted(X_test["state"].unique())))

model_dir = ROOT / "models"
model_dir.mkdir(parents=True, exist_ok=True)
report = {
    "evaluation_split": "state_group_holdout",
    "dataset_status": "demo_data_unverified",
    "train_rows": int(len(X_train)),
    "test_rows": int(len(X_test)),
    "held_out_states": sorted(X_test["state"].unique().tolist()),
    "model": "RandomForestRegressor",
    "model_mae_days": round(float(mae), 3),
    "model_rmse_days": round(float(rmse), 3),
    "model_r2": round(float(r2), 4),
    "median_baseline_mae_days": round(float(mean_absolute_error(y_test, baseline_pred)), 3),
    "target": "final_additional_delay_days",
}
(model_dir / "model_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

results = pd.DataFrame(
    {"Actual Delay": y_test, "Predicted Delay": y_pred.round(0)}
)

print("\n===== SAMPLE PREDICTIONS =====")
print(results.head(10))

joblib.dump(pipeline, model_dir / "nexterra_delay_model.pkl", compress=3)

print("\nModel saved successfully!")
