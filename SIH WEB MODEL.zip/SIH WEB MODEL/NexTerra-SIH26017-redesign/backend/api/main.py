import os
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator

from src.model_service import (
    get_alerts,
    get_case_by_id,
    get_cases,
    get_model_info,
    get_stats,
    load_cases,
    MODEL_PATH,
    predict_case,
)

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT.parent / "frontend"

# ==========================================
# Create FastAPI application
# ==========================================

app = FastAPI(
    title="NexTerra AI API",
    description="Land acquisition delay prediction API — SIH26017",
    version="1.0",
)

# CORS is disabled for the bundled same-origin UI. Set CORS_ORIGINS to an
# explicit comma-separated allowlist only when hosting a separate frontend.

allowed_origins = [origin.strip() for origin in os.getenv("CORS_ORIGINS", "").split(",") if origin.strip()]
if allowed_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
    )


# ==========================================
# Load + cache bulk predictions once, at startup
# (so /cases, /alerts, /stats are fast — no recomputation per request)
# ==========================================


@app.on_event("startup")
def startup_event():
    if MODEL_PATH.is_file():
        load_cases()


# ==========================================
# Input schema for a single custom prediction
# ==========================================


class LandAcquisitionCase(BaseModel):
    state: str = Field(min_length=2, max_length=80)
    district: str = Field(min_length=2, max_length=100)
    land_type: str = Field(min_length=2, max_length=40)
    acquisition_stage: str = Field(min_length=2, max_length=40)

    case_age_days: int = Field(ge=0, le=10000)
    days_in_stage: int = Field(ge=0, le=5000)
    number_of_landowners: int = Field(ge=1, le=1000000)
    litigation_present: int = Field(ge=0, le=1)
    number_of_objections: int = Field(ge=0, le=1000000)
    compensation_delay_days: int = Field(ge=0, le=10000)
    previous_stage_delay_days: int = Field(ge=0, le=10000)
    historical_delay_rate: float = Field(ge=0, le=1)
    land_area_hectares: float = Field(gt=0, le=100000000)

    @model_validator(mode="after")
    def stage_cannot_exceed_case_age(self):
        if self.days_in_stage > self.case_age_days:
            raise ValueError("days_in_stage cannot exceed case_age_days")
        return self


# ==========================================
# Health check
# ==========================================


@app.get("/")
def root():
    if (FRONTEND / "index.html").is_file():
        return FileResponse(FRONTEND / "index.html")
    return {"message": "NexTerra AI API is running", "docs": "/docs"}


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "NexTerra AI API", "model_available": MODEL_PATH.is_file()}


@app.get("/api/model-info")
def model_info():
    return get_model_info()


# ==========================================
# Predict a single, custom case
# (not from the dataset — e.g. a form submission)
# ==========================================


@app.post("/predict")
@app.post("/api/predict")
def predict(case: LandAcquisitionCase):
    try:
        return predict_case(case.model_dump())
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed. See README for setup.") from exc


# ==========================================
# List cases from the dataset, with filters + pagination
# Used to populate the dashboard's case table.
# ==========================================


@app.get("/cases")
def list_cases(
    state: Optional[str] = None,
    land_type: Optional[str] = None,
    acquisition_stage: Optional[str] = None,
    risk_level: Optional[str] = Query(None, description="LOW, MEDIUM, or HIGH"),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
):
    try:
        return get_cases(state=state, land_type=land_type, acquisition_stage=acquisition_stage,
                         risk_level=risk_level, limit=limit, offset=offset)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed. See README for setup.") from exc


# ==========================================
# Full prediction + SHAP reasons for one specific case
# Used for the dashboard's case-detail page.
# ==========================================


@app.get("/cases/{case_id}")
def get_case(case_id: str):
    try:
        result = get_case_by_id(case_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed. See README for setup.") from exc

    if result is None:
        raise HTTPException(status_code=404, detail=f"Case '{case_id}' not found")

    return result


# ==========================================
# High-risk cases only, worst first
# Used for the dashboard's alerts panel.
# ==========================================


@app.get("/alerts")
def alerts(limit: int = Query(50, ge=1, le=500)):
    try:
        return {"alerts": get_alerts(limit=limit)}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed. See README for setup.") from exc


# ==========================================
# Summary numbers for dashboard charts
# (risk-tier distribution, per-state high-risk %)
# ==========================================


@app.get("/stats")
def stats():
    try:
        return get_stats()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Prediction model is not installed. See README for setup.") from exc


if FRONTEND.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND), name="frontend")
