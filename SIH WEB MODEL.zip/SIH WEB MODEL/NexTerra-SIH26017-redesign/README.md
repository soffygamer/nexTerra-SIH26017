# NexTerra — SIH 26017

The project is split into two clear folders: `frontend/` contains the case assessment UI, and `backend/` contains the FastAPI service, model, training code, and demo data.

## Start the app on Windows

Open PowerShell in the `backend` folder:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn api.main:app --reload
```

Open http://127.0.0.1:8000. The API docs are at `/docs`; model status is at `/api/health`.

To retrain the model with the updated state-held-out evaluation and median baseline, run `python src/train_model.py` from `backend/`.

## Backend endpoints

- `POST /api/predict` — delay estimate, risk tier, and SHAP factors (`/predict` remains an alias).
- `GET /cases`, `GET /cases/{case_id}`, `GET /alerts`, `GET /stats` — demo case views.
- `GET /api/health` — service and model artifact status.
- `GET /api/model-info` — validation report and data caveats for the current model.

## Model limitations

The supplied 8,000-row dataset includes placeholder districts such as `Bihar District 1`, so treat results as a demo until the dataset source and generation method are confirmed. The current packaged model has no verifiable evaluation report. Retraining adds held-out-state MAE, RMSE, R² and median-baseline MAE to `models/model_validation.json`; these remain demo-data results. The risk cutoffs (120 and 200 days) are prototype settings. SHAP describes model output, not causation. Location categories absent from training are ignored. Validate on documented case records and confirm thresholds with domain stakeholders before operational use.

For a valid prediction task, define a case snapshot date and predict only information not yet known at that date. Do not train on later outcomes or post-snapshot fields.
