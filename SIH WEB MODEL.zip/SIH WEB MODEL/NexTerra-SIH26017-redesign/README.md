# NexTerra — SIH 26017

NexTerra is an AI-powered predictive analytics system for early detection of land acquisition delays.

The project is split into two clear folders:

- `frontend/` contains the case assessment UI.
- `backend/` contains the FastAPI service, model, training code, and demo data.

The ML component predicts the expected additional delay in days, assigns a prototype risk tier, and uses SHAP to explain the main factors contributing to an individual prediction.

---

## ML Dataset

The current ML model uses an **8,000-row synthetic land-acquisition dataset**.

```text
Rows:              8,000
Model input features: 20
Training rows:     5,787
Test rows:         2,213
Held-out states:   Andhra Pradesh, Rajasthan, Uttar Pradesh
```

The dataset contains seven acquisition stages:

1. Preliminary Notification
2. Social Impact Assessment
3. Declaration & Survey
4. Expert Group Review
5. Award (Compensation Determination)
6. Compensation Disbursement
7. Possession

It also represents multiple litigation types and objection categories so that delay is not modeled as being caused by a single attribute.

### Objection categories

- Compensation Dispute
- Land Ownership / Title Dispute
- Land Measurement / Boundary Dispute
- Rehabilitation & Resettlement
- Land Use / Project Impact
- Documentation / Procedural Objection
- `No Objection` for cases without objections

### Litigation categories

- No Litigation
- Land Ownership / Title
- Compensation / Valuation
- Rehabilitation & Resettlement
- Procedural / Administrative

The dataset is **synthetic** and should be treated as prototype/demo data rather than verified administrative case records.

---

## Model

The ML component currently uses a **Random Forest Regressor**.

Pipeline:

```text
8,000 synthetic cases
        ↓
Categorical + numeric preprocessing
        ↓
State-grouped train/test split
        ↓
Random Forest regression
        ↓
Expected additional delay
        ↓
Prototype risk tier
        ↓
SHAP explanation
```

The model predicts:

```text
final_additional_delay_days
```

This represents the expected number of additional days a case may take beyond the point at which the prediction is made.

---

## Current Model Evaluation

The current training run produced:

```text
Rows: 8000
Features: 20
Train rows: 5787
Test rows: 2213
Held-out states: Andhra Pradesh, Rajasthan, Uttar Pradesh

===== MODEL PERFORMANCE =====
MAE  : 25.53 days
RMSE : 31.65 days
R²   : 0.2784
Baseline median MAE: 30.11 days
```

The model's MAE is lower than the median-prediction baseline on this synthetic held-out test set.

These metrics **do not establish real-world prediction accuracy** because the current dataset is synthetic.

### Sample predictions

```text
Actual Delay    Predicted Delay
54              59
68              66
72              90
92              86
10              68
105             62
105             92
13              62
93              73
32              90
```

---

## Train/Test Method

The evaluation uses a **state-grouped holdout**.

Entire states are kept out of the training set and evaluated as test data:

```text
Andhra Pradesh
Rajasthan
Uttar Pradesh
```

This provides a geographic generalization check within the synthetic dataset.

The training script also compares the Random Forest against a simple median-prediction baseline.

Validation metadata is written to:

```text
models/model_validation.json
```

---

## Global Feature Importance

Global Random Forest feature importance was checked to ensure that the redesigned synthetic dataset did not cause one feature to dominate the model.

Current results:

```text
numeric__days_in_stage                                  0.1142
numeric__case_age_days                                  0.0868
categorical__litigation_type_No Litigation              0.0816
numeric__litigation_present                             0.0768
numeric__compensation_delay_days                        0.0741
numeric__land_area_hectares                             0.0724
numeric__historical_delay_rate                          0.0705
numeric__previous_stage_delay_days                      0.0615
numeric__documentation_completeness_pct                 0.0586
numeric__number_of_landowners                           0.0535
categorical__acquisition_stage_Compensation Disbursement 0.0324
numeric__number_of_objections                           0.0159
numeric__stage_median_days_reference                    0.0152
categorical__acquisition_stage_Preliminary Notification  0.0123
categorical__land_type_Agricultural                     0.0089
categorical__project_type_Highway                       0.0079
categorical__land_type_Industrial                       0.0074
categorical__project_type_Industrial Corridor           0.0068
numeric__objection_present                              0.0063
categorical__objection_category_No Objection             0.0062
```

The importance is distributed across stage duration, case age, litigation, compensation, land characteristics, historical delay, previous-stage delay, documentation and other factors rather than being concentrated in one artificially dominant feature.

Feature importance describes model behavior and **does not establish causality**.

---

## Explainable AI

NexTerra uses **SHAP (SHapley Additive exPlanations)** for case-level explanations.

For an individual case, SHAP identifies features that pushed the prediction higher or lower.

Example test case:

```text
Predicted additional delay: 153 days
Risk level: HIGH
```

Top SHAP contributors:

```text
Compensation delay       +15.82 days
Litigation present       +12.77 days
Acquisition stage        +12.04 days
Previous-stage delay      +5.54 days
Days in current stage     +4.84 days
```

A positive SHAP value means the feature pushed the model's prediction higher for that specific case.

SHAP values are **model contributions, not proof of causal effects**.

A separate non-litigation test case also produced an explanation dominated by:

```text
Days in current stage     +9.74 days
Number of objections      +7.35 days
Objection category        +4.45 days
Historical delay rate     +3.18 days
Objections present        +2.77 days
```

This demonstrates that the prototype can identify different model pathways to higher predicted delay rather than relying only on litigation.

---

## Risk Classification

The current prototype converts predicted delay into a risk tier:

```text
< 120 days       LOW
120–199 days     MEDIUM
≥ 200 days       HIGH
```

These thresholds are prototype settings and should be validated against real operational requirements before deployment.

---

## Start the App on Windows

Open PowerShell in the `backend` folder:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn api.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

API documentation:

```text
http://127.0.0.1:8000/docs
```

Model status:

```text
http://127.0.0.1:8000/api/health
```

---

## Retrain the Model

From the `backend/` directory:

```bash
python src/train_model.py
```

The training script generates:

```text
models/nexterra_delay_model.pkl
models/model_validation.json
```

The trained `.pkl` file is a generated model artifact and should not be committed to Git if it exceeds repository limits.

---

## Check Global Feature Importance

Run:

```bash
python src/check_feature_importance.py
```

This prints the Random Forest's global feature importance after preprocessing.

---

## Backend Endpoints

- `POST /api/predict` — delay estimate, risk tier, and SHAP factors (`/predict` remains an alias).
- `GET /cases` — paginated demo cases.
- `GET /cases/{case_id}` — individual case prediction and explanation.
- `GET /alerts` — high-risk demo cases.
- `GET /stats` — dashboard summary statistics.
- `GET /api/health` — service and model artifact status.
- `GET /api/model-info` — validation report and data caveats for the current model.

The frontend/backend integration is handled by the other project components.

---

## Model Limitations

- The current dataset is **synthetic**.
- The model has not been validated on verified government land-acquisition case records.
- Current metrics do not establish real-world prediction accuracy.
- The current test R² is **0.2784**, so the model explains only a limited portion of variation in the synthetic test target.
- The model can make substantial errors on some low-delay cases.
- The risk cutoffs of 120 and 200 days are prototype settings.
- SHAP explains model output, not causation.
- Location categories absent from training may not be represented effectively by the model.
- Real-world deployment would require documented historical records, data-quality checks, appropriate validation, and domain review.

For a valid prediction task, define a case snapshot date and predict only information that would have been available at that date. Do not train on later outcomes or post-snapshot fields.

---

## Technologies

### Machine Learning

- Python
- Pandas
- NumPy
- Scikit-learn
- Random Forest
- SHAP
- Joblib

### API

- FastAPI
- Pydantic
- Uvicorn

### Frontend

The frontend is maintained separately from the ML component.

---

## Project Structure

```text
NexTerra/
├── frontend/
│   └── ...
│
└── backend/
    ├── api/
    │   └── main.py
    ├── data/
    │   └── nexterra_land_acquisition_8000_redesigned_v2.csv
    ├── models/
    │   ├── nexterra_delay_model.pkl
    │   └── model_validation.json
    ├── src/
    │   ├── train_model.py
    │   ├── model_service.py
    │   └── check_feature_importance.py
    ├── requirements.txt
    └── README.md
```
